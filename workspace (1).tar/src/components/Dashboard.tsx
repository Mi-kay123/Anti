import { motion } from 'framer-motion';
import { 
  Brain, Heart, Trophy, Tv, Cpu, Newspaper, 
  Sparkles, Compass, TrendingUp, Quote
} from 'lucide-react';
import type { Section } from '../App';

interface DashboardProps {
  userName: string;
  userAge: number | null;
  onNavigate: (section: Section) => void;
}

const dailyQuotes = [
  "The unexamined life is not worth living. — Socrates",
  "Between stimulus and response there is a space. In that space is our power to choose. — Viktor Frankl",
  "What lies behind us and what lies before us are tiny matters compared to what lies within us. — Ralph Waldo Emerson",
  "The privilege of a lifetime is to become who you truly are. — Carl Jung",
  "In the middle of difficulty lies opportunity. — Albert Einstein",
  "You are not a drop in the ocean. You are the entire ocean in a drop. — Rumi",
  "The only way to do great work is to love what you do. — Steve Jobs",
];

const principles = [
  { title: "Curiosity over Assumptions", desc: "Discover what makes you happy through reflection, not prescription.", icon: "🔍" },
  { title: "Connection over Isolation", desc: "Build healthy relationships. No app replaces human intimacy.", icon: "🤝" },
  { title: "Individuality over One-Size-Fits-All", desc: "Your fulfilling life looks different from anyone else's.", icon: "✨" },
  { title: "Evidence over Hype", desc: "We explain what research supports vs. what's just a hypothesis.", icon: "📊" },
  { title: "Progress over Perfection", desc: "Understand yourself better. Navigate life with more tools.", icon: "🌱" },
];

export default function Dashboard({ userName, userAge, onNavigate }: DashboardProps) {
  const todayQuote = dailyQuotes[new Date().getDate() % dailyQuotes.length];

  const sections = [
    { id: 'psychology' as Section, title: 'Mind & Emotions', desc: 'Explore psychology, emotional intelligence, and behavioral patterns', icon: <Brain size={28} />, color: 'from-blue-600 to-cyan-600' },
    { id: 'life' as Section, title: 'Life & Relationships', desc: 'Navigate love, friendship, family, and personal growth', icon: <Heart size={28} />, color: 'from-pink-600 to-rose-600' },
    { id: 'sports' as Section, title: 'Sports', desc: 'All 5 major leagues — teams, history, and updates', icon: <Trophy size={28} />, color: 'from-green-600 to-emerald-600' },
    { id: 'entertainment' as Section, title: 'Entertainment', desc: 'Movies, music, gaming, and pop culture worldwide', icon: <Tv size={28} />, color: 'from-purple-600 to-violet-600' },
    { id: 'technology' as Section, title: 'Technology', desc: 'Latest innovations, AI, gadgets, and digital trends', icon: <Cpu size={28} />, color: 'from-orange-600 to-amber-600' },
    { id: 'news' as Section, title: 'Latest News', desc: 'World events, politics, science, and more', icon: <Newspaper size={28} />, color: 'from-red-600 to-pink-600' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12"
      >
        <div className="flex items-center justify-center gap-2 mb-4">
          <Sparkles className="text-purple-400" size={24} />
          <span className="text-purple-300 font-medium">Your personalized space</span>
          <Sparkles className="text-purple-400" size={24} />
        </div>
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          Welcome back, <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">{userName}</span>
        </h1>
        {userAge && (
          <p className="text-gray-400 text-lg">Age {userAge} — A great age to explore, learn, and grow</p>
        )}
      </motion.div>

      {/* Daily Quote */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="mb-12 bg-gradient-to-r from-purple-900/50 to-pink-900/50 backdrop-blur-sm border border-purple-500/20 rounded-2xl p-6 md:p-8"
      >
        <Quote className="text-purple-400 mb-3" size={32} />
        <p className="text-xl md:text-2xl text-gray-200 italic mb-3">"{todayQuote}"</p>
        <p className="text-sm text-purple-300">— Your daily reflection</p>
      </motion.div>

      {/* Principles */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mb-12"
      >
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <Compass className="text-purple-400" size={24} />
          Our Philosophy
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
          {principles.map((p, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + i * 0.1 }}
              className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all"
            >
              <span className="text-2xl mb-2 block">{p.icon}</span>
              <h3 className="font-semibold text-sm text-white mb-1">{p.title}</h3>
              <p className="text-xs text-gray-400">{p.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Section Cards */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <TrendingUp className="text-purple-400" size={24} />
          Explore
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sections.map((section, i) => (
            <motion.button
              key={section.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 + i * 0.1 }}
              onClick={() => onNavigate(section.id)}
              className="group relative overflow-hidden rounded-2xl p-6 text-left transition-all hover:scale-[1.02]"
              whileHover={{ y: -4 }}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${section.color} opacity-20 group-hover:opacity-30 transition-opacity`} />
              <div className="relative">
                <div className="mb-4 p-3 rounded-xl bg-white/10 inline-block">
                  {section.icon}
                </div>
                <h3 className="text-xl font-bold mb-2">{section.title}</h3>
                <p className="text-gray-300 text-sm">{section.desc}</p>
              </div>
            </motion.button>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
