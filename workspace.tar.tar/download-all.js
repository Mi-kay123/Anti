#!/usr/bin/env node

/**
 * Anti Life - Download All Files Script
 * 
 * This script creates a ZIP file containing all project files.
 * Run: node download-all.js
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Check if archiver is installed, if not install it
try {
  require.resolve('archiver');
} catch (e) {
  console.log('Installing archiver package...');
  execSync('npm install archiver --no-save', { stdio: 'inherit' });
}

const archiver = require('archiver');

const output = fs.createWriteStream('anti-life-project.zip');
const archive = archiver('zip', { zlib: { level: 9 } });

output.on('close', () => {
  console.log(`\n✅ Successfully created anti-life-project.zip (${archive.pointer()} total bytes)`);
  console.log('\n📋 Next steps:');
  console.log('   1. Extract the ZIP file');
  console.log('   2. Run: npm install');
  console.log('   3. Run: npm run dev');
  console.log('   4. Open http://localhost:5173 in your browser\n');
});

archive.on('error', (err) => {
  throw err;
});

archive.pipe(output);

// Files and directories to include
const filesToInclude = [
  'src/',
  'index.html',
  'package.json',
  'tsconfig.json',
  'vite.config.js',
  'README.md',
];

// Add files to archive
filesToInclude.forEach(file => {
  const filePath = path.join(__dirname, file);
  if (fs.existsSync(filePath)) {
    if (fs.statSync(filePath).isDirectory()) {
      archive.directory(filePath, file);
    } else {
      archive.file(filePath, { name: file });
    }
  }
});

// Create README if it doesn't exist
const readmePath = path.join(__dirname, 'README.md');
if (!fs.existsSync(readmePath)) {
  const readmeContent = `# Anti Life Web App

## Overview
A comprehensive web app for exploring psychology, life, relationships, sports, entertainment, technology, and news.

## Installation

\`\`\`bash
npm install
npm run dev
\`\`\`

Then open http://localhost:5173 in your browser.

## Features

### 🧠 Mind & Emotions
- Emotion wheel for identifying feelings
- Psychological concepts with evidence-based information
- Reflection prompts and journaling

### ❤️ Life & Relationships
- Relationship topics with research-backed tips
- Love language quiz
- Connection experiments

### ⚽ Sports
- All 5 major European leagues (Premier League, La Liga, Bundesliga, Serie A, Ligue 1)
- Team histories, stadiums, and achievements
- Search and filter functionality

### 🎬 Entertainment
- Movies & TV shows
- Music artists and trends
- Gaming news
- Trending entertainment topics

### 💻 Technology
- AI & Machine Learning
- Gadgets & Devices
- Space & Science
- Cybersecurity
- Innovation

### 📰 Latest News
- World news
- Politics
- Science
- Business
- Health
- Environment

## Philosophy

1. **Curiosity over Assumptions** - Discover through reflection
2. **Connection over Isolation** - Build healthy relationships
3. **Individuality over One-Size-Fits-All** - Personalized experience
4. **Evidence over Hype** - Research-backed information
5. **Progress over Perfection** - Understand yourself better

## Tech Stack

- React 18
- TypeScript
- Vite
- Tailwind CSS
- Framer Motion
- Lucide React Icons

## License

MIT
`;
  fs.writeFileSync(readmePath, readmeContent);
  archive.file(readmePath, { name: 'README.md' });
}

archive.finalize();
