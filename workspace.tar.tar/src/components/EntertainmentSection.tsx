import { useState } from 'react';
import { motion } from 'framer-motion';
import { Tv, Film, Music, Gamepad2, Star, TrendingUp } from 'lucide-react';

export default function EntertainmentSection() {
  const [activeCategory, setActiveCategory] = useState('movies');

  const categories = [
    { id: 'movies', label: 'Movies', icon: <Film size={18} /> },
    { id: 'music', label: 'Music', icon: <Music size={18} /> },
    { id: 'gaming', label: 'Gaming', icon: <Gamepad2 size={18} /> },
    { id: 'trending', label: 'Trending', icon: <TrendingUp size={18} /> },
  ];

  const movies = [
    { title: "Dune: Part Three", genre: "Sci-Fi", year: 2026, rating: 9.1, desc: "Villeneuve concludes epic adaptation." },
    { title: "The Batman Part II", genre: "Action", year: 2026, rating: 8.7, desc: "Pattinson returns as Dark Knight." },
    { title: "Avatar: Fire and Ash", genre: "Sci-Fi", year: 2025, rating: 8.4, desc: "Cameron explores fire regions of Pandora." },
    { title: "Mickey 17", genre: "Sci-Fi", year: 2025, rating: 8.2, desc: "Bong Joon-ho sci-fi thriller." },
  ];

  const musicData = [
    { artist: "Kendrick Lamar", genre: "Hip-Hop", highlight: "Pulitzer winner pushes boundaries.", trending: true },
    { artist: "Billie Eilish", genre: "Pop/Alt", highlight: "Multiple Grammy wins.", trending: true },
    { artist: "Taylor Swift", genre: "Pop", highlight: "Eras Tour highest-grossing ever.", trending: true },
  ];

  const gamingList = [
    { title: "GTA VI", platform: "PS5, Xbox", hype: "Most anticipated game ever.", status: "Coming 2025/26" },
    { title: "Zelda TotK", platform: "Switch", hype: "Open-world masterpiece.", status: "Available" },
  ];

  const trendingList = [
    { title: "AI Music Debate", desc: "Industry grapples with AI songs.", tag: "Culture" },
    { title: "Streaming Consolidation", desc: "Platforms merge services.", tag: "Industry" },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
          <Tv className="text-purple-400" size={36} />
          Entertainment - Worldwide
        </h1>
        <p className="text-gray-400 text-lg">Movies, music, gaming, and pop culture from around the globe</p>
      </motion.div>

      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {categories.map(cat => (
          <button key={cat.id} onClick={() => setActiveCategory(cat.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all ${
              activeCategory === cat.id ? 'bg-purple-600/30 text-purple-300 border border-purple-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}>
            {cat.icon} {cat.label}
          </button>
        ))}
      </div>

      {activeCategory === 'movies' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {movies.map((m, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all">
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-bold text-lg">{m.title}</h3>
                <div className="flex items-center gap-1 text-yellow-400"><Star size={14} /><span className="text-sm">{m.rating}</span></div>
              </div>
              <div className="flex gap-2 mb-2">
                <span className="px-2 py-0.5 bg-purple-500/20 rounded text-xs text-purple-300">{m.genre}</span>
                <span className="px-2 py-0.5 bg-white/10 rounded text-xs text-gray-400">{m.year}</span>
              </div>
              <p className="text-sm text-gray-300">{m.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      )}

      {activeCategory === 'music' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
          {musicData.map((a, i) => (
            <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-white/5 border border-white/10 rounded-xl p-4 flex items-center gap-4 hover:bg-white/10 transition-all">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-xl">🎵</div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold">{a.artist}</h3>
                  {a.trending && <span className="px-2 py-0.5 bg-red-500/20 rounded text-xs text-red-300">🔥</span>}
                </div>
                <p className="text-sm text-purple-300">{a.genre}</p>
                <p className="text-sm text-gray-400 mt-1">{a.highlight}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      )}

      {activeCategory === 'gaming' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {gamingList.map((g, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all">
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-bold text-lg">{g.title}</h3>
                <span className={`px-2 py-0.5 rounded text-xs ${g.status === 'Available' ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'}`}>{g.status}</span>
              </div>
              <p className="text-sm text-purple-300 mb-1">{g.platform}</p>
              <p className="text-sm text-gray-300">{g.hype}</p>
            </motion.div>
          ))}
        </motion.div>
      )}

      {activeCategory === 'trending' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
          {trendingList.map((item, i) => (
            <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all">
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2 py-0.5 bg-purple-500/20 rounded text-xs text-purple-300">{item.tag}</span>
                <TrendingUp size={14} className="text-purple-400" />
              </div>
              <h3 className="font-bold mb-1">{item.title}</h3>
              <p className="text-sm text-gray-400">{item.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
}
