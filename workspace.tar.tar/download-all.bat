@echo off
REM Anti Life - Download All Files Script for Windows
REM Run: download-all.bat

echo 📦 Creating ZIP archive of all project files...

REM Check if PowerShell is available
where powershell >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    powershell -Command "Compress-Archive -Path 'src', 'index.html', 'package.json', 'tsconfig.json', 'vite.config.js', 'README.md' -DestinationPath 'anti-life-project.zip' -Force"
) else (
    echo ❌ PowerShell not found. Please install PowerShell or use the Node.js script instead.
    pause
    exit /b 1
)

REM Check if ZIP was created
if exist "anti-life-project.zip" (
    echo.
    echo ✅ Successfully created anti-life-project.zip
    echo.
    echo 📋 Next steps:
    echo    1. Extract the ZIP file
    echo    2. Run: npm install
    echo    3. Run: npm run dev
    echo    4. Open http://localhost:5173 in your browser
    echo.
    for %%A in ("anti-life-project.zip") do echo 📊 File size: %%~zA bytes
) else (
    echo ❌ Error creating ZIP file
    pause
    exit /b 1
)

pause
