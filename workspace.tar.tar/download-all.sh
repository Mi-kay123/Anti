#!/bin/bash

# Anti Life - Download All Files Script for Mac/Linux
# Run: ./download-all.sh

echo "📦 Creating ZIP archive of all project files..."

# Create ZIP file
zip -r anti-life-project.zip \
  src/ \
  index.html \
  package.json \
  tsconfig.json \
  vite.config.js \
  README.md \
  2>/dev/null

# Check if ZIP was created
if [ -f "anti-life-project.zip" ]; then
  echo ""
  echo "✅ Successfully created anti-life-project.zip"
  echo ""
  echo "📋 Next steps:"
  echo "   1. Extract the ZIP file"
  echo "   2. Run: npm install"
  echo "   3. Run: npm run dev"
  echo "   4. Open http://localhost:5173 in your browser"
  echo ""
  echo "📊 File size: $(du -h anti-life-project.zip | cut -f1)"
else
  echo "❌ Error creating ZIP file"
  exit 1
fi
