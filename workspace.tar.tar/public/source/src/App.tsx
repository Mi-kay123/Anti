import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Brain, Heart, Trophy, Tv, Cpu, Newspaper, 
  Sparkles, ChevronRight, Menu, X, Home, 
  Compass, Users, Zap, BookOpen
} from 'lucide-react';
import Onboarding from './components/Onboarding';
import Dashboard from './components/Dashboard';
import PsychologySection from './components/PsychologySection';
import LifeSection from './components/LifeSection';
import SportsSection from './components/SportsSection';
import EntertainmentSection from './components/EntertainmentSection';
import TechnologySection from './components/TechnologySection';
import NewsSection from './components/NewsSection';

export type Section = 'dashboard' | 'psychology' | 'life' | 'sports' | 'entertainment' | 'technology' | 'news';

function App() {
  const [userName, setUserName] = useState('');
  const [userAge, setUserAge] = useState<number | null>(null);
  const [onboarded, setOnboarded] = useState(false);
  const [activeSection, setActiveSection] = useState<Section>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleOnboardingComplete = (name: string, age: number) => {
    setUserName(name);
    setUserAge(age);
    setOnboarded(true);
  };

  const navItems: { id: Section; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'Home', icon: <Home size={20} /> },
    { id: 'psychology', label: 'Mind & Emotions', icon: <Brain size={20} /> },
    { id: 'life', label: 'Life & Love', icon: <Heart size={20} /> },
    { id: 'sports', label: 'Sports', icon: <Trophy size={20} /> },
    { id: 'entertainment', label: 'Entertainment', icon: <Tv size={20} /> },
    { id: 'technology', label: 'Technology', icon: <Cpu size={20} /> },
    { id: 'news', label: 'News', icon: <Newspaper size={20} /> },
  ];

  if (!onboarded) {
    return <Onboarding onComplete={handleOnboardingComplete} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white">
      <nav className="fixed top-0 left-0 right-0 z-50 bg-gray-900/80 backdrop-blur-xl border-b border-purple-500/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <motion.div className="flex items-center gap-2 cursor-pointer" whileHover={{ scale: 1.05 }} onClick={() => setActiveSection('dashboard')}>
              <Sparkles className="text-purple-400" size={24} />
              <span className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Anti Life</span>
            </motion.div>
            <div className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <motion.button key={item.id} onClick={() => setActiveSection(item.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${activeSection === item.id ? 'bg-purple-600/30 text-purple-300 border border-purple-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
                  whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  {item.icon}
                  <span className="hidden lg:inline">{item.label}</span>
                </motion.button>
              ))}
            </div>
            <div className="hidden md:flex items-center gap-3">
              <span className="text-sm text-gray-400">Welcome, <span className="text-purple-300">{userName}</span></span>
            </div>
            <button className="md:hidden p-2 rounded-lg hover:bg-white/10" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-gray-900/95 backdrop-blur-xl border-b border-purple-500/20">
              <div className="px-4 py-3 space-y-1">
                {navItems.map((item) => (
                  <button key={item.id} onClick={() => { setActiveSection(item.id); setMobileMenuOpen(false); }}
                    className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg text-sm font-medium transition-all ${activeSection === item.id ? 'bg-purple-600/30 text-purple-300' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
                    {item.icon}{item.label}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
      <main className="pt-16 min-h-screen">
        <AnimatePresence mode="wait">
          <motion.div key={activeSection} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.3 }}>
            {activeSection === 'dashboard' && <Dashboard userName={userName} userAge={userAge} onNavigate={setActiveSection} />}
            {activeSection === 'psychology' && <PsychologySection userAge={userAge} />}
            {activeSection === 'life' && <LifeSection userAge={userAge} />}
            {activeSection === 'sports' && <SportsSection />}
            {activeSection === 'entertainment' && <EntertainmentSection />}
            {activeSection === 'technology' && <TechnologySection />}
            {activeSection === 'news' && <NewsSection />}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

export default App;
