import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Lightbulb, Target, BookOpen, ChevronDown, ChevronUp, Sparkles, RotateCcw } from 'lucide-react';

interface PsychologySectionProps { userAge: number | null; }

const emotionWheel = [
  { name: "Joy", color: "bg-yellow-500", emotions: ["Contentment", "Gratitude", "Pride", "Excitement", "Serenity", "Amusement"] },
  { name: "Sadness", color: "bg-blue-500", emotions: ["Loneliness", "Grief", "Disappointment", "Melancholy", "Helplessness", "Nostalgia"] },
  { name: "Anger", color: "bg-red-500", emotions: ["Frustration", "Resentment", "Irritation", "Rage", "Jealousy", "Bitterness"] },
  { name: "Fear", color: "bg-purple-500", emotions: ["Anxiety", "Dread", "Insecurity", "Panic", "Worry", "Vulnerability"] },
  { name: "Surprise", color: "bg-pink-500", emotions: ["Shock", "Awe", "Confusion", "Amazement", "Disbelief", "Wonder"] },
  { name: "Disgust", color: "bg-green-500", emotions: ["Contempt", "Revulsion", "Aversion", "Distaste", "Repulsion", "Disdain"] },
];

const psychologicalConcepts = [
  { title: "Emotional Intelligence (EQ)", description: "The ability to recognize, understand, and manage our own emotions.", research: "Research by Daniel Goleman shows EQ can be more important than IQ.", evidence: "Strong evidence", practices: ["Journal your emotions daily", "Practice naming emotions precisely", "Pause before reacting", "Develop empathy through active listening"], icon: "🧠" },
  { title: "Cognitive Behavioral Patterns", description: "Our thoughts, feelings, and behaviors are interconnected.", research: "CBT is one of the most researched therapeutic approaches.", evidence: "Strong evidence", practices: ["Identify negative thought patterns", "Challenge cognitive distortions", "Keep a thought record", "Practice behavioral experiments"], icon: "🔄" },
  { title: "Attachment Theory", description: "Our early relationships shape how we connect with others.", research: "Developed by Bowlby and Ainsworth. Styles: Secure, Anxious, Avoidant, Disorganized.", evidence: "Strong evidence", practices: ["Reflect on early relationships", "Notice relationship patterns", "Practice secure behaviors", "Communicate needs clearly"], icon: "🔗" },
  { title: "Flow State", description: "Complete absorption in an activity where time disappears.", research: "Csikszentmihalyi's research shows flow occurs when challenge matches skill.", evidence: "Strong evidence", practices: ["Find appropriate challenges", "Eliminate distractions", "Set clear goals", "Focus on process"], icon: "🌊" },
  { title: "The Shadow Self", description: "Parts of ourselves we hide or deny.", research: "Carl Jung's concept. Suppressed aspects affect behavior.", evidence: "Moderate evidence", practices: ["Notice what triggers you", "Journal uncomfortable feelings", "Accept all parts of yourself", "Explore projections"], icon: "🌑" },
  { title: "Neuroplasticity", description: "Your brain can rewire itself throughout life.", research: "Meditation, learning, and new experiences change brain structure.", evidence: "Strong evidence", practices: ["Learn new skills", "Practice mindfulness", "Challenge routines", "Exercise regularly"], icon: "⚡" },
  { title: "Self-Determination Theory", description: "Three needs: Autonomy, Competence, Relatedness.", research: "Deci and Ryan's research shows these are essential for well-being.", evidence: "Strong evidence", practices: ["Cultivate autonomy", "Develop competence", "Nurture connections", "Align with values"], icon: "🎯" },
  { title: "The Hedonic Treadmill", description: "We adapt to changes, returning to baseline happiness.", research: "Lottery winners and accident victims return to similar happiness.", evidence: "Moderate evidence", practices: ["Practice gratitude", "Seek novelty", "Focus on experiences", "Cultivate meaning"], icon: "🎡" },
];

const reflectionPrompts = [
  "What emotion have you been avoiding lately?",
  "When did you last feel completely absorbed in something?",
  "What pattern in your relationships keeps repeating?",
  "If your anxiety could speak, what would it say?",
  "What would you do differently without fear of judgment?",
  "What part of yourself do you hide from others?",
  "When do you feel most like yourself?",
  "What belief about yourself might be a story, not truth?",
  "What are you grateful for today?",
  "What would you tell your younger self?",
];

export default function PsychologySection({ userAge }: PsychologySectionProps) {
  const [selectedEmotion, setSelectedEmotion] = useState<number | null>(null);
  const [expandedConcept, setExpandedConcept] = useState<number | null>(null);
  const [currentPrompt, setCurrentPrompt] = useState(0);
  const [journalEntry, setJournalEntry] = useState('');
  const [savedEntries, setSavedEntries] = useState<string[]>([]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3"><Brain className="text-blue-400" size={36} />Mind & Emotions</h1>
        <p className="text-gray-400 text-lg">Understanding your inner world — psychology, emotions, and behavior explained</p>
      </motion.div>
      <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mb-12">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2"><Sparkles className="text-yellow-400" size={24} />Emotion Wheel</h2>
        <p className="text-gray-400 mb-4">Click on an emotion to explore its nuances.</p>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-4">
          {emotionWheel.map((emotion, i) => (
            <motion.button key={i} onClick={() => setSelectedEmotion(selectedEmotion === i ? null : i)}
              className={`p-4 rounded-xl border transition-all ${selectedEmotion === i ? 'border-white/50 scale-105 shadow-lg' : 'border-white/10 hover:border-white/30'} bg-white/5`}
              whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <div className={`w-8 h-8 rounded-full ${emotion.color} mx-auto mb-2`} />
              <span className="font-medium text-sm">{emotion.name}</span>
            </motion.button>
          ))}
        </div>
        <AnimatePresence>
          {selectedEmotion !== null && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="bg-white/5 border border-white/10 rounded-xl p-4">
              <h3 className="font-bold text-lg mb-2">{emotionWheel[selectedEmotion].name} — Sub-emotions</h3>
              <div className="flex flex-wrap gap-2">
                {emotionWheel[selectedEmotion].emotions.map((e, i) => (<span key={i} className={`px-3 py-1 rounded-full text-sm ${emotionWheel[selectedEmotion].color} bg-opacity-20 border border-white/20`}>{e}</span>))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.section>
      <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mb-12">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2"><BookOpen className="text-purple-400" size={24} />Psychological Concepts</h2>
        <div className="space-y-3">
          {psychologicalConcepts.map((concept, i) => (
            <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 + i * 0.05 }} className="bg-white/5 border border-white/10 rounded-xl overflow-hidden">
              <button onClick={() => setExpandedConcept(expandedConcept === i ? null : i)} className="w-full p-4 text-left flex items-center gap-3 hover:bg-white/5 transition-all">
                <span className="text-2xl">{concept.icon}</span>
                <div className="flex-1"><h3 className="font-bold">{concept.title}</h3><p className="text-sm text-gray-400">{concept.description}</p></div>
                <span className={`px-2 py-1 rounded text-xs font-medium ${concept.evidence === 'Strong evidence' ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'}`}>{concept.evidence}</span>
                {expandedConcept === i ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
              </button>
              <AnimatePresence>
                {expandedConcept === i && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="px-4 pb-4">
                    <div className="bg-white/5 rounded-lg p-4 space-y-3">
                      <div><h4 className="font-semibold text-purple-300 text-sm mb-1">Research</h4><p className="text-sm text-gray-300">{concept.research}</p></div>
                      <div><h4 className="font-semibold text-green-300 text-sm mb-1">Try This</h4><ul className="space-y-1">{concept.practices.map((p, j) => (<li key={j} className="text-sm text-gray-300 flex items-start gap-2"><span className="text-green-400 mt-1">•</span>{p}</li>))}</ul></div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </motion.section>
      <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="mb-12">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2"><Lightbulb className="text-yellow-400" size={24} />Reflection Space</h2>
        <div className="bg-gradient-to-r from-yellow-900/30 to-orange-900/30 border border-yellow-500/20 rounded-xl p-6 mb-4">
          <p className="text-lg text-yellow-100 italic mb-4">"{reflectionPrompts[currentPrompt]}"</p>
          <button onClick={() => setCurrentPrompt((currentPrompt + 1) % reflectionPrompts.length)} className="flex items-center gap-2 px-4 py-2 bg-yellow-500/20 hover:bg-yellow-500/30 rounded-lg text-yellow-300 text-sm transition-all"><RotateCcw size={16} /> New Prompt</button>
        </div>
        <div className="bg-white/5 border border-white/10 rounded-xl p-4">
          <h3 className="font-semibold mb-3 flex items-center gap-2"><Target className="text-purple-400" size={20} />Your Private Journal</h3>
          <textarea value={journalEntry} onChange={(e) => setJournalEntry(e.target.value)} placeholder="Write your thoughts here..." className="w-full h-32 px-4 py-3 bg-white/5 border border-purple-500/20 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-purple-400 resize-none" />
          <button onClick={() => { if (journalEntry.trim()) { setSavedEntries([journalEntry, ...savedEntries]); setJournalEntry(''); } }} disabled={!journalEntry.trim()} className="mt-3 px-4 py-2 bg-purple-600 hover:bg-purple-500 rounded-lg text-sm font-medium transition-all disabled:opacity-50">Save Entry</button>
        </div>
      </motion.section>
    </div>
  );
}
