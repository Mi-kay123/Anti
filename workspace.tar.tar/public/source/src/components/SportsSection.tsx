import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trophy, Search, Calendar, Star } from 'lucide-react';
import { leagues } from '../data/sportsData';

export default function SportsSection() {
  const [selectedLeague, setSelectedLeague] = useState(0);
  const [selectedTeam, setSelectedTeam] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const filteredTeams = leagues[selectedLeague].teams.filter(team => team.name.toLowerCase().includes(searchQuery.toLowerCase()) || team.city.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3"><Trophy className="text-green-400" size={36} />Sports — The Beautiful Game</h1>
        <p className="text-gray-400 text-lg">All 5 major European leagues — teams, history, and stories</p>
      </motion.div>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mb-6">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {leagues.map((league, i) => (
            <motion.button key={i} onClick={() => { setSelectedLeague(i); setSelectedTeam(null); setSearchQuery(''); }}
              className={`flex items-center gap-2 px-4 py-3 rounded-xl font-medium whitespace-nowrap transition-all ${selectedLeague === i ? 'bg-green-600/30 text-green-300 border border-green-500/30' : 'bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10'}`}
              whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <span className="text-xl">{league.flag}</span><span>{league.name}</span>
            </motion.button>
          ))}
        </div>
      </motion.div>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 border border-green-500/20 rounded-xl p-4 mb-6">
        <div className="flex items-center justify-between">
          <div><h2 className="text-xl font-bold flex items-center gap-2">{leagues[selectedLeague].flag} {leagues[selectedLeague].name}</h2><p className="text-gray-400 text-sm">{leagues[selectedLeague].country} • {leagues[selectedLeague].teams.length} teams</p></div>
          <Calendar className="text-green-400" size={24} />
        </div>
      </motion.div>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={20} />
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder={`Search teams in ${leagues[selectedLeague].name}...`} className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-green-400 transition-all" />
        </div>
      </motion.div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filteredTeams.map((team, i) => (
          <motion.button key={team.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 + i * 0.02 }}
            onClick={() => setSelectedTeam(selectedTeam === i ? null : i)}
            className={`text-left p-4 rounded-xl border transition-all ${selectedTeam === i ? 'bg-white/10 border-green-500/30' : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'}`} whileHover={{ scale: 1.01 }}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm" style={{ backgroundColor: team.color }}>{team.name.charAt(0)}</div>
              <div className="flex-1"><h3 className="font-bold text-sm">{team.name}</h3><p className="text-xs text-gray-400">{team.city} • Est. {team.founded}</p></div>
              <div className="flex items-center gap-1 text-yellow-400"><Star size={14} /><span className="text-xs font-medium">{team.titles}</span></div>
            </div>
          </motion.button>
        ))}
      </div>
      <AnimatePresence>
        {selectedTeam !== null && filteredTeams[selectedTeam] && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={() => setSelectedTeam(null)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={(e) => e.stopPropagation()} className="bg-gray-900 border border-white/20 rounded-2xl p-6 max-w-lg w-full max-h-[80vh] overflow-y-auto">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 rounded-full flex items-center justify-center text-white font-bold text-2xl" style={{ backgroundColor: filteredTeams[selectedTeam].color }}>{filteredTeams[selectedTeam].name.charAt(0)}</div>
                <div><h2 className="text-2xl font-bold">{filteredTeams[selectedTeam].name}</h2><p className="text-gray-400">{filteredTeams[selectedTeam].city}, {leagues[selectedLeague].country}</p></div>
              </div>
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="bg-white/5 rounded-lg p-3 text-center"><p className="text-xs text-gray-400">Founded</p><p className="font-bold text-lg">{filteredTeams[selectedTeam].founded}</p></div>
                <div className="bg-white/5 rounded-lg p-3 text-center"><p className="text-xs text-gray-400">Titles</p><p className="font-bold text-lg">{filteredTeams[selectedTeam].titles}</p></div>
                <div className="bg-white/5 rounded-lg p-3 text-center"><p className="text-xs text-gray-400">League</p><p className="font-bold text-xs">{leagues[selectedLeague].name}</p></div>
              </div>
              <div className="bg-white/5 rounded-lg p-4 mb-4"><h3 className="font-semibold text-green-300 mb-2">🏟️ Stadium</h3><p className="text-gray-300">{filteredTeams[selectedTeam].stadium}</p></div>
              <div className="bg-white/5 rounded-lg p-4"><h3 className="font-semibold text-green-300 mb-2">📖 History & Identity</h3><p className="text-gray-300 text-sm leading-relaxed">{filteredTeams[selectedTeam].history}</p></div>
              <button onClick={() => setSelectedTeam(null)} className="mt-4 w-full py-2 bg-white/10 hover:bg-white/20 rounded-lg text-sm transition-all">Close</button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
