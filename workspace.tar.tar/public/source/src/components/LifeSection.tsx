import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, MessageCircle, Users, Shield, Sparkles, ArrowRight, RotateCcw } from 'lucide-react';

interface LifeSectionProps { userAge: number | null; }

const loveLanguages = [
  { name: "Words of Affirmation", icon: "💬", desc: "Verbal expressions of love", examples: ["Compliments", "Encouraging words", "Written notes"] },
  { name: "Quality Time", icon: "⏰", desc: "Undivided attention", examples: ["Deep conversations", "Shared activities", "Being present"] },
  { name: "Receiving Gifts", icon: "🎁", desc: "Thoughtful tokens", examples: ["Handmade items", "Surprise gifts", "Thoughtful gestures"] },
  { name: "Acts of Service", icon: "🤲", desc: "Actions that show care", examples: ["Cooking meals", "Running errands", "Helping with tasks"] },
  { name: "Physical Touch", icon: "🤗", desc: "Physical connection", examples: ["Holding hands", "Hugs", "Physical closeness"] },
];

const relationshipTopics = [
  { title: "Building Emotional Intimacy", description: "The foundation of deep connection.", research: "Brené Brown shows vulnerability is the birthplace of connection.", tips: ["Share fears and dreams", "Listen without fixing", "Create rituals of connection"], icon: "💝" },
  { title: "Healthy Conflict Resolution", description: "Learning to fight fair is essential.", research: "Gottman's Four Horsemen: Criticism, Contempt, Defensiveness, Stonewalling.", tips: ["Use 'I feel' statements", "Take breaks when flooded", "Focus on the issue"], icon: "⚖️" },
  { title: "The Science of Attraction", description: "Biology, psychology, and social factors.", research: "Similarity in values matters more than opposites attract.", tips: ["Notice what attracts you", "Shared values predict success", "Attachment styles matter"], icon: "✨" },
  { title: "Friendship & Community", description: "Quality friendships are essential for well-being.", research: "Harvard Study: quality relationships are #1 predictor of happiness.", tips: ["Invest in 3-5 close friendships", "Show up consistently", "Allow evolution"], icon: "👥" },
  { title: "Self-Love & Boundaries", description: "You cannot pour from an empty cup.", research: "Kristin Neff's self-compassion research reduces anxiety.", tips: ["Set boundaries without guilt", "Practice self-compassion", "Know your values"], icon: "🛡️" },
  { title: "Grief & Loss", description: "Loss is the price of love.", research: "No right way to grieve. Dual Process Model suggests oscillation.", tips: ["Allow all emotions", "Don't rush", "Seek connection"], icon: "🕊️" },
];

const connectionExperiments = [
  "Send a message to someone you haven't talked to in a while",
  "Ask someone 'What's been on your mind lately?' and really listen",
  "Write down 3 things you appreciate about someone and tell them",
  "Join a community group related to something you care about",
  "Have a conversation where you ask more questions than answers",
  "Reach out to someone who might be lonely",
  "Share something vulnerable with a trusted friend",
  "Give your full attention in one conversation — no phone",
];

export default function LifeSection({ userAge }: LifeSectionProps) {
  const [activeTab, setActiveTab] = useState<'explore' | 'languages' | 'experiments'>('explore');
  const [expandedTopic, setExpandedTopic] = useState<number | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [currentExperiment, setCurrentExperiment] = useState(0);

  const quizQuestions = ["You'd feel most loved if your partner/friend:", "After a hard day, what helps most?", "What makes you feel most connected?", "What would hurt most?", "How do you naturally show care?"];
  const quizOptions = [
    ["Tells you they're proud", "Spends the evening with you", "Surprises you with something", "Does something helpful", "Gives you a long hug"],
    ["Hearing 'I believe in you'", "Someone sitting with you", "Receiving a caring gift", "Someone handling chores", "Physical comfort"],
    ["Deep conversations", "Quality time together", "Thoughtful gestures", "Acts of kindness", "Physical affection"],
    ["Harsh words", "Being ignored", "Forgotten dates", "Doing everything alone", "Physical distance"],
    ["Tell what I admire", "Plan special time", "Find the perfect gift", "Help without being asked", "Show affection physically"],
  ];

  const handleQuizAnswer = (answer: number) => {
    const newAnswers = [...quizAnswers, answer];
    setQuizAnswers(newAnswers);
    if (newAnswers.length >= 5) setShowResults(true);
  };

  const getLoveLanguageResult = () => {
    const counts = [0, 0, 0, 0, 0];
    quizAnswers.forEach(a => counts[a]++);
    return loveLanguages[counts.indexOf(Math.max(...counts))];
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3"><Heart className="text-pink-400" size={36} />Life & Relationships</h1>
        <p className="text-gray-400 text-lg">Navigating love, connection, and the human experience</p>
      </motion.div>
      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {[{ id: 'explore' as const, label: 'Explore Topics', icon: <MessageCircle size={18} /> }, { id: 'languages' as const, label: 'Love Language Quiz', icon: <Sparkles size={18} /> }, { id: 'experiments' as const, label: 'Connection Experiments', icon: <Users size={18} /> }].map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all ${activeTab === tab.id ? 'bg-pink-600/30 text-pink-300 border border-pink-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>{tab.icon} {tab.label}</button>
        ))}
      </div>
      {activeTab === 'explore' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
          {relationshipTopics.map((topic, i) => (
            <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }} className="bg-white/5 border border-white/10 rounded-xl overflow-hidden">
              <button onClick={() => setExpandedTopic(expandedTopic === i ? null : i)} className="w-full p-4 text-left flex items-center gap-3 hover:bg-white/5 transition-all">
                <span className="text-2xl">{topic.icon}</span>
                <div className="flex-1"><h3 className="font-bold">{topic.title}</h3><p className="text-sm text-gray-400">{topic.description}</p></div>
                <ArrowRight size={20} className={`transition-transform ${expandedTopic === i ? 'rotate-90' : ''}`} />
              </button>
              <AnimatePresence>
                {expandedTopic === i && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="px-4 pb-4">
                    <div className="bg-white/5 rounded-lg p-4 space-y-3">
                      <div><h4 className="font-semibold text-pink-300 text-sm mb-1">Research</h4><p className="text-sm text-gray-300">{topic.research}</p></div>
                      <div><h4 className="font-semibold text-green-300 text-sm mb-1">Tips</h4><ul className="space-y-1">{topic.tips.map((tip, j) => (<li key={j} className="text-sm text-gray-300 flex items-start gap-2"><span className="text-pink-400 mt-1">•</span>{tip}</li>))}</ul></div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </motion.div>
      )}
      {activeTab === 'languages' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          {!showResults ? (
            <div className="bg-white/5 border border-white/10 rounded-xl p-6">
              <h2 className="text-xl font-bold mb-2">Discover Your Love Language</h2>
              <p className="text-gray-400 mb-6">Answer 5 questions to discover how you give and receive love.</p>
              {quizAnswers.length < 5 && (
                <div>
                  <div className="mb-2 text-sm text-gray-400">Question {quizAnswers.length + 1} of 5</div>
                  <h3 className="text-lg font-semibold mb-4">{quizQuestions[quizAnswers.length]}</h3>
                  <div className="space-y-2">
                    {quizOptions[quizAnswers.length].map((option, i) => (
                      <motion.button key={i} onClick={() => handleQuizAnswer(i)} className="w-full p-3 text-left bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 hover:border-pink-500/30 transition-all" whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }}>{option}</motion.button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-gradient-to-r from-pink-900/30 to-purple-900/30 border border-pink-500/20 rounded-xl p-6">
              <h2 className="text-2xl font-bold mb-4">Your Love Language: {getLoveLanguageResult().name} {getLoveLanguageResult().icon}</h2>
              <p className="text-gray-300 mb-4">{getLoveLanguageResult().desc}</p>
              <button onClick={() => { setQuizAnswers([]); setShowResults(false); }} className="flex items-center gap-2 px-4 py-2 bg-pink-600/30 hover:bg-pink-600/50 rounded-lg text-pink-300 text-sm transition-all"><RotateCcw size={16} /> Take Quiz Again</button>
            </div>
          )}
        </motion.div>
      )}
      {activeTab === 'experiments' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <div className="bg-gradient-to-r from-green-900/30 to-teal-900/30 border border-green-500/20 rounded-xl p-6">
            <div className="text-sm text-green-300 mb-2">Experiment {currentExperiment + 1} of {connectionExperiments.length}</div>
            <p className="text-xl text-white mb-6">{connectionExperiments[currentExperiment]}</p>
            <button onClick={() => setCurrentExperiment((currentExperiment + 1) % connectionExperiments.length)} className="flex items-center gap-2 px-4 py-2 bg-green-600/30 hover:bg-green-600/50 rounded-lg text-green-300 text-sm transition-all">Next Experiment <ArrowRight size={16} /></button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
