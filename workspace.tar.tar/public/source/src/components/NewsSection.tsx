import { useState } from 'react';
import { motion } from 'framer-motion';
import { Newspaper, Globe, AlertCircle, TrendingUp, Clock } from 'lucide-react';

export default function NewsSection() {
  const [activeCategory, setActiveCategory] = useState('world');
  const newsCategories = [
    { id: 'world', label: 'World', icon: <Globe size={18} /> },
    { id: 'politics', label: 'Politics', icon: <AlertCircle size={18} /> },
    { id: 'science', label: 'Science', icon: <TrendingUp size={18} /> },
    { id: 'business', label: 'Business', icon: <TrendingUp size={18} /> },
    { id: 'health', label: 'Health', icon: <AlertCircle size={18} /> },
    { id: 'environment', label: 'Environment', icon: <Globe size={18} /> },
  ];
  const worldNews = [{ title: "Global Climate Summit Reaches Historic Agreement", desc: "195 nations agree to accelerated emissions targets.", region: "Global", time: "2 hours ago", importance: "High" }, { title: "EU Expands to Include Western Balkans", desc: "European Union welcomes new member states.", region: "Europe", time: "4 hours ago", importance: "High" }];
  const politicsNews = [{ title: "UN Security Council Reform Advances", desc: "Framework for expanding UN Security Council gains support.", region: "Global", time: "3 hours ago" }, { title: "Digital Rights Charter Adopted", desc: "50 nations adopt comprehensive digital rights charter.", region: "Global", time: "5 hours ago" }];
  const scienceNews = [{ title: "Breakthrough in Alzheimer's Treatment", desc: "New drug shows 80% reduction in cognitive decline.", region: "Medical", time: "2 hours ago" }, { title: "Nuclear Fusion Plant Construction Begins", desc: "First commercial fusion power plant breaks ground.", region: "Energy", time: "4 hours ago" }];
  const businessNews = [{ title: "Four-Day Work Week Becomes Standard", desc: "After successful pilots, becomes law in several European nations.", region: "Europe", time: "3 hours ago" }, { title: "Cryptocurrency Regulation Finalized", desc: "G20 nations agree on comprehensive regulation.", region: "Global", time: "5 hours ago" }];
  const healthNews = [{ title: "mRNA Technology Targets Multiple Cancers", desc: "Personalized mRNA vaccines show remarkable results.", region: "Global", time: "2 hours ago" }, { title: "Mental Health Apps Get Validation", desc: "First digital therapeutics receive clinical approval.", region: "Global", time: "4 hours ago" }];
  const environmentNews = [{ title: "Amazon Deforestation Falls 80%", desc: "Combined efforts lead to dramatic reduction.", region: "South America", time: "3 hours ago" }, { title: "Ocean Plastic Cleanup Milestone", desc: "Project removes billionth kilogram of plastic.", region: "Global", time: "5 hours ago" }];
  const allNews: Record<string, any[]> = { world: worldNews, politics: politicsNews, science: scienceNews, business: businessNews, health: healthNews, environment: environmentNews };
  const currentNews = allNews[activeCategory] || worldNews;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3"><Newspaper className="text-red-400" size={36} />Latest News - Worldwide</h1>
        <p className="text-gray-400 text-lg">Stay informed about what's happening around the globe</p>
      </motion.div>
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="mb-6 bg-gradient-to-r from-red-900/40 to-orange-900/40 border border-red-500/30 rounded-xl p-4">
        <div className="flex items-center gap-3"><span className="px-2 py-1 bg-red-500 rounded text-xs font-bold animate-pulse">LIVE</span><p className="text-sm text-gray-200"><strong>Breaking:</strong> Global developments continue to reshape our world.</p></div>
      </motion.div>
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {newsCategories.map(cat => (<button key={cat.id} onClick={() => setActiveCategory(cat.id)} className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all ${activeCategory === cat.id ? 'bg-red-600/30 text-red-300 border border-red-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>{cat.icon} {cat.label}</button>))}
      </div>
      <motion.div key={activeCategory} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {currentNews.map((item, i) => (
          <motion.article key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="bg-white/5 border border-white/10 rounded-xl p-5 hover:bg-white/10 hover:border-white/20 transition-all group">
            <div className="flex items-center gap-2 mb-3">
              <span className="px-2 py-0.5 bg-red-500/20 rounded text-xs text-red-300">{item.region}</span>
              <span className="flex items-center gap-1 text-xs text-gray-500"><Clock size={12} /> {item.time}</span>
              {item.importance === 'High' && <span className="px-2 py-0.5 bg-yellow-500/20 rounded text-xs text-yellow-300">Important</span>}
            </div>
            <h3 className="font-bold text-lg mb-2 group-hover:text-red-300 transition-colors">{item.title}</h3>
            <p className="text-sm text-gray-400 leading-relaxed">{item.desc}</p>
          </motion.article>
        ))}
      </motion.div>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="mt-8 bg-blue-900/30 border border-blue-500/20 rounded-xl p-4">
        <p className="text-sm text-blue-200">📰 <strong>Note:</strong> This is a curated summary. For full coverage, check multiple verified news sources.</p>
      </motion.div>
    </div>
  );
}
