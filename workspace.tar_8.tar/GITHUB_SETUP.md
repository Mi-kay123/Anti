# 📦 Anti Life - GitHub Package Creator

This script will create a complete GitHub-ready folder with all project files.

## 🚀 How to Use

### Step 1: Run the copy script
```bash
chmod +x copy-all-files.sh
./copy-all-files.sh
```

### Step 2: Navigate to the created folder
```bash
cd anti-life-github-final
```

### Step 3: Install dependencies
```bash
npm install
```

### Step 4: Start the development server
```bash
npm run dev
```

### Step 5: Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit: Anti Life web app"
git remote add origin YOUR_GITHUB_REPO_URL
git push -u origin main
```

## 📋 What Gets Copied

The script will copy:
- ✅ All source files (src/)
- ✅ All configuration files (package.json, tsconfig.json, vite.config.js, etc.)
- ✅ index.html
- ✅ .gitignore
- ✅ README.md

## 🎯 Final Result

You'll get a complete, ready-to-deploy folder that you can push directly to GitHub!

---

**Ready to share your Anti Life app with the world! 🌍**
