# 🌟 Anti Life Web App

> Not anti-life. Pro-**understanding** life.

A comprehensive, interactive web application designed to help you explore psychology, emotions, relationships, and stay connected with the world through sports, entertainment, technology, and news.

## 🎯 Philosophy

1. **Curiosity over Assumptions** - Discover what makes you happy through reflection, not prescription
2. **Connection over Isolation** - Build healthy relationships (no app replaces human intimacy)
3. **Individuality over One-Size-Fits-All** - Your fulfilling life looks different from anyone else's
4. **Evidence over Hype** - We explain what research supports vs. what's just a hypothesis
5. **Progress over Perfection** - Understand yourself better and navigate life with more tools

## 📦 Download All Files

### Option 1: Using the Download Scripts (Recommended)

**For Mac/Linux:**
```bash
chmod +x download-all.sh
./download-all.sh
```

**For Windows:**
```cmd
download-all.bat
```

**Using Node.js (Cross-platform):**
```bash
node download-all.js
```

### Option 2: Manual Download

If you're viewing this in a web interface, look for a "Download" button or use your browser's download feature to save all files.

### Option 3: Copy-Paste Method

If none of the above work, you can manually copy each file from the `src/` directory structure shown below.

## 🚀 Installation

After downloading/extracting the files:

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

Then open http://localhost:5173 in your browser.

## 📁 Project Structure

```
anti-life/
├── src/
│   ├── App.tsx                      # Main application component
│   ├── main.tsx                     # Entry point
│   ├── index.css                    # Global styles
│   ├── components/
│   │   ├── Onboarding.tsx           # User onboarding flow
│   │   ├── Dashboard.tsx            # Main dashboard
│   │   ├── PsychologySection.tsx    # Mind & Emotions
│   │   ├── LifeSection.tsx          # Life & Relationships
│   │   ├── SportsSection.tsx        # Sports (5 major leagues)
│   │   ├── EntertainmentSection.tsx # Entertainment worldwide
│   │   ├── TechnologySection.tsx    # Technology news
│   │   └── NewsSection.tsx          # Latest news
│   └── data/
│       └── sportsData.ts            # Sports teams data
├── index.html                       # HTML entry point
├── package.json                     # Dependencies
├── tsconfig.json                    # TypeScript config
├── vite.config.js                   # Vite config
├── download-all.js                  # Node.js download script
├── download-all.sh                  # Unix/Linux download script
├── download-all.bat                 # Windows download script
└── README.md                        # This file
```

## 🎨 Features

### 🧠 Mind & Emotions
- **Emotion Wheel** - Identify and explore your feelings with nuanced sub-emotions
- **Psychological Concepts** - Evidence-based understanding of:
  - Emotional Intelligence
  - Cognitive Behavioral Patterns
  - Attachment Theory
  - Flow State
  - The Shadow Self
  - Neuroplasticity
  - Self-Determination Theory
  - The Hedonic Treadmill
- **Reflection Prompts** - Guided questions for self-discovery
- **Private Journal** - Write and save your thoughts

### ❤️ Life & Relationships
- **Relationship Topics** with research-backed tips:
  - Building Emotional Intimacy
  - Healthy Conflict Resolution
  - The Science of Attraction
  - Friendship & Community
  - Self-Love & Boundaries
  - Grief & Loss
- **Love Language Quiz** - Discover how you give and receive love
- **Connection Experiments** - Small, evidence-based actions to build connection

### ⚽ Sports
All 5 major European leagues with complete team information:
- **Premier League** (England) - 20 teams
- **La Liga** (Spain) - 20 teams
- **Bundesliga** (Germany) - 18 teams
- **Serie A** (Italy) - 20 teams
- **Ligue 1** (France) - 18 teams

Each team includes:
- Founding year
- Stadium
- Number of titles
- Historical significance
- Current status

### 🎬 Entertainment (Worldwide)
- **Movies & TV** - Latest releases with ratings
- **Music** - Trending artists and highlights
- **Gaming** - Most anticipated and available games
- **Trending** - Pop culture moments

### 💻 Technology (Worldwide)
- **AI & Machine Learning** - Latest developments
- **Gadgets & Devices** - New releases
- **Space & Science** - Exploration and discoveries
- **Cybersecurity** - Important updates
- **Innovation** - Breakthrough technologies

### 📰 Latest News (Worldwide)
- **World News** - Global events
- **Politics** - Political developments
- **Science** - Scientific breakthroughs
- **Business** - Economic news
- **Health** - Medical advances
- **Environment** - Climate and sustainability

## 🛠️ Tech Stack

- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **Framer Motion** - Animations
- **Lucide React** - Icons

## 🎯 For Introverts

This app is specifically designed with introverts in mind:
- Self-paced exploration
- Private journaling
- No social pressure
- Deep, meaningful content
- Comfortable navigation
- No forced interactions

## 📝 Notes

- All data is for educational and informational purposes
- Sports data includes team histories and achievements
- News and entertainment content is curated summaries
- The app emphasizes evidence-based information
- Personal data (journal entries) stays on your device

## 🤝 Contributing

Feel free to fork, modify, and improve this project!

## 📄 License

MIT License - Feel free to use this project however you'd like.

## 💡 Tips for Best Experience

1. Take your time exploring each section
2. Use the reflection prompts regularly
3. Try the connection experiments in real life
4. Follow your curiosity, not expectations
5. Remember: progress over perfection

---

**Built with ❤️ for those who think deeply and feel intensely**
