export interface BibleBook {
  id: number;
  name: string;
  testament: 'old' | 'new';
  chapters: number;
  category: string;
  keyVerse?: string;
}

export interface Verse {
  text: string;
  ref: string;
  isJesus?: boolean;
}

// All 66 books of the Bible
export const bibleBooks: BibleBook[] = [
  // Old Testament (39 books)
  { id: 1, name: 'Genesis', testament: 'old', chapters: 50, category: 'Law' },
  { id: 2, name: 'Exodus', testament: 'old', chapters: 40, category: 'Law' },
  { id: 3, name: 'Leviticus', testament: 'old', chapters: 27, category: 'Law' },
  { id: 4, name: 'Numbers', testament: 'old', chapters: 36, category: 'Law' },
  { id: 5, name: 'Deuteronomy', testament: 'old', chapters: 34, category: 'Law' },
  { id: 6, name: 'Joshua', testament: 'old', chapters: 24, category: 'History' },
  { id: 7, name: 'Judges', testament: 'old', chapters: 21, category: 'History' },
  { id: 8, name: 'Ruth', testament: 'old', chapters: 4, category: 'History' },
  { id: 9, name: '1 Samuel', testament: 'old', chapters: 31, category: 'History' },
  { id: 10, name: '2 Samuel', testament: 'old', chapters: 24, category: 'History' },
  { id: 11, name: '1 Kings', testament: 'old', chapters: 22, category: 'History' },
  { id: 12, name: '2 Kings', testament: 'old', chapters: 25, category: 'History' },
  { id: 13, name: '1 Chronicles', testament: 'old', chapters: 29, category: 'History' },
  { id: 14, name: '2 Chronicles', testament: 'old', chapters: 36, category: 'History' },
  { id: 15, name: 'Ezra', testament: 'old', chapters: 10, category: 'History' },
  { id: 16, name: 'Nehemiah', testament: 'old', chapters: 13, category: 'History' },
  { id: 17, name: 'Esther', testament: 'old', chapters: 10, category: 'History' },
  { id: 18, name: 'Job', testament: 'old', chapters: 42, category: 'Wisdom' },
  { id: 19, name: 'Psalms', testament: 'old', chapters: 150, category: 'Wisdom' },
  { id: 20, name: 'Proverbs', testament: 'old', chapters: 31, category: 'Wisdom' },
  { id: 21, name: 'Ecclesiastes', testament: 'old', chapters: 12, category: 'Wisdom' },
  { id: 22, name: 'Song of Solomon', testament: 'old', chapters: 8, category: 'Wisdom' },
  { id: 23, name: 'Isaiah', testament: 'old', chapters: 66, category: 'Major Prophets' },
  { id: 24, name: 'Jeremiah', testament: 'old', chapters: 52, category: 'Major Prophets' },
  { id: 25, name: 'Lamentations', testament: 'old', chapters: 5, category: 'Major Prophets' },
  { id: 26, name: 'Ezekiel', testament: 'old', chapters: 48, category: 'Major Prophets' },
  { id: 27, name: 'Daniel', testament: 'old', chapters: 12, category: 'Major Prophets' },
  { id: 28, name: 'Hosea', testament: 'old', chapters: 14, category: 'Minor Prophets' },
  { id: 29, name: 'Joel', testament: 'old', chapters: 3, category: 'Minor Prophets' },
  { id: 30, name: 'Amos', testament: 'old', chapters: 9, category: 'Minor Prophets' },
  { id: 31, name: 'Obadiah', testament: 'old', chapters: 1, category: 'Minor Prophets' },
  { id: 32, name: 'Jonah', testament: 'old', chapters: 4, category: 'Minor Prophets' },
  { id: 33, name: 'Micah', testament: 'old', chapters: 7, category: 'Minor Prophets' },
  { id: 34, name: 'Nahum', testament: 'old', chapters: 3, category: 'Minor Prophets' },
  { id: 35, name: 'Habakkuk', testament: 'old', chapters: 3, category: 'Minor Prophets' },
  { id: 36, name: 'Zephaniah', testament: 'old', chapters: 3, category: 'Minor Prophets' },
  { id: 37, name: 'Haggai', testament: 'old', chapters: 2, category: 'Minor Prophets' },
  { id: 38, name: 'Zechariah', testament: 'old', chapters: 14, category: 'Minor Prophets' },
  { id: 39, name: 'Malachi', testament: 'old', chapters: 4, category: 'Minor Prophets' },
  
  // New Testament (27 books)
  { id: 40, name: 'Matthew', testament: 'new', chapters: 28, category: 'Gospels' },
  { id: 41, name: 'Mark', testament: 'new', chapters: 16, category: 'Gospels' },
  { id: 42, name: 'Luke', testament: 'new', chapters: 24, category: 'Gospels' },
  { id: 43, name: 'John', testament: 'new', chapters: 21, category: 'Gospels' },
  { id: 44, name: 'Acts', testament: 'new', chapters: 28, category: 'History' },
  { id: 45, name: 'Romans', testament: 'new', chapters: 16, category: 'Pauline Epistles' },
  { id: 46, name: '1 Corinthians', testament: 'new', chapters: 16, category: 'Pauline Epistles' },
  { id: 47, name: '2 Corinthians', testament: 'new', chapters: 13, category: 'Pauline Epistles' },
  { id: 48, name: 'Galatians', testament: 'new', chapters: 6, category: 'Pauline Epistles' },
  { id: 49, name: 'Ephesians', testament: 'new', chapters: 6, category: 'Pauline Epistles' },
  { id: 50, name: 'Philippians', testament: 'new', chapters: 4, category: 'Pauline Epistles' },
  { id: 51, name: 'Colossians', testament: 'new', chapters: 4, category: 'Pauline Epistles' },
  { id: 52, name: '1 Thessalonians', testament: 'new', chapters: 5, category: 'Pauline Epistles' },
  { id: 53, name: '2 Thessalonians', testament: 'new', chapters: 3, category: 'Pauline Epistles' },
  { id: 54, name: '1 Timothy', testament: 'new', chapters: 6, category: 'Pauline Epistles' },
  { id: 55, name: '2 Timothy', testament: 'new', chapters: 4, category: 'Pauline Epistles' },
  { id: 56, name: 'Titus', testament: 'new', chapters: 3, category: 'Pauline Epistles' },
  { id: 57, name: 'Philemon', testament: 'new', chapters: 1, category: 'Pauline Epistles' },
  { id: 58, name: 'Hebrews', testament: 'new', chapters: 13, category: 'General Epistles' },
  { id: 59, name: 'James', testament: 'new', chapters: 5, category: 'General Epistles' },
  { id: 60, name: '1 Peter', testament: 'new', chapters: 5, category: 'General Epistles' },
  { id: 61, name: '2 Peter', testament: 'new', chapters: 3, category: 'General Epistles' },
  { id: 62, name: '1 John', testament: 'new', chapters: 5, category: 'General Epistles' },
  { id: 63, name: '2 John', testament: 'new', chapters: 1, category: 'General Epistles' },
  { id: 64, name: '3 John', testament: 'new', chapters: 1, category: 'General Epistles' },
  { id: 65, name: 'Jude', testament: 'new', chapters: 1, category: 'General Epistles' },
  { id: 66, name: 'Revelation', testament: 'new', chapters: 22, category: 'Prophecy' },
];

// Jesus' sayings (words in red)
export const jesusSayings: Verse[] = [
  { text: 'Love the Lord your God with all your heart and with all your soul and with all your mind.', ref: 'Matthew 22:37', isJesus: true },
  { text: 'Love your neighbor as yourself.', ref: 'Matthew 22:39', isJesus: true },
  { text: 'Do to others what you would have them do to you.', ref: 'Matthew 7:12', isJesus: true },
  { text: 'Blessed are the merciful, for they will be shown mercy.', ref: 'Matthew 5:7', isJesus: true },
  { text: 'Blessed are the peacemakers, for they will be called children of God.', ref: 'Matthew 5:9', isJesus: true },
  { text: 'You have heard that it was said, "Love your neighbor and hate your enemy." But I tell you, love your enemies and pray for those who persecute you.', ref: 'Matthew 5:43-44', isJesus: true },
  { text: 'Forgive, and you will be forgiven.', ref: 'Luke 6:37', isJesus: true },
  { text: 'Let your light shine before others, that they may see your good deeds and glorify your Father in heaven.', ref: 'Matthew 5:16', isJesus: true },
  { text: 'Ask and it will be given to you; seek and you will find; knock and the door will be opened to you.', ref: 'Matthew 7:7', isJesus: true },
  { text: 'Therefore do not worry about tomorrow, for tomorrow will worry about itself.', ref: 'Matthew 6:34', isJesus: true },
  { text: 'I am the way and the truth and the life.', ref: 'John 14:6', isJesus: true },
  { text: 'Come to me, all you who are weary and burdened, and I will give you rest.', ref: 'Matthew 11:28', isJesus: true },
  { text: 'Be kind and compassionate to one another, forgiving each other, just as in Christ God forgave you.', ref: 'Ephesians 4:32', isJesus: false },
  { text: 'A new command I give you: Love one another. As I have loved you, so you must love one another.', ref: 'John 13:34', isJesus: true },
  { text: 'The greatest among you will be your servant.', ref: 'Matthew 23:11', isJesus: true },
  { text: 'Whatever you did for one of the least of these brothers and sisters of mine, you did for me.', ref: 'Matthew 25:40', isJesus: true },
  { text: 'Judge not, that you be not judged.', ref: 'Matthew 7:1', isJesus: true },
  { text: 'With man this is impossible, but with God all things are possible.', ref: 'Matthew 19:26', isJesus: true },
  { text: 'I tell you the truth, whatever you did not do for one of the least of these, you did not do for me.', ref: 'Matthew 25:45', isJesus: true },
  { text: 'Peace I leave with you; my peace I give you.', ref: 'John 14:27', isJesus: true },
];

// Verses organized by moral category
export const versesByMoral: Record<string, Verse[]> = {
  kindness: [
    { text: 'Be kind and compassionate to one another, forgiving each other, just as in Christ God forgave you.', ref: 'Ephesians 4:32' },
    { text: 'A kind person will be blessed, for they share their bread with the poor.', ref: 'Proverbs 22:9' },
    { text: 'Let all that you do be done in love.', ref: '1 Corinthians 16:14' },
  ],
  honesty: [
    { text: 'The Lord detests lying lips, but he delights in people who are trustworthy.', ref: 'Proverbs 12:22' },
    { text: 'Therefore each of you must put off falsehood and speak truthfully to your neighbor.', ref: 'Ephesians 4:25' },
    { text: 'Who may ascend the mountain of the Lord? Who may stand in his holy place? The one who has clean hands and a pure heart.', ref: 'Psalm 24:3-4' },
  ],
  respect: [
    { text: 'Show proper respect to everyone, love the family of believers, fear God, honor the emperor.', ref: '1 Peter 2:17' },
    { text: 'Do nothing out of selfish ambition or vain conceit. Rather, in humility value others above yourselves.', ref: 'Philippians 2:3' },
    { text: 'Honor your father and your mother.', ref: 'Exodus 20:12' },
  ],
  courage: [
    { text: 'Be strong and courageous. Do not be afraid; do not be discouraged, for the Lord your God will be with you wherever you go.', ref: 'Joshua 1:9' },
    { text: 'The Lord is my light and my salvation—whom shall I fear?', ref: 'Psalm 27:1' },
    { text: 'For God has not given us a spirit of fear, but of power and of love and of a sound mind.', ref: '2 Timothy 1:7' },
  ],
  patience: [
    { text: 'Love is patient, love is kind. It does not envy, it does not boast, it is not proud.', ref: '1 Corinthians 13:4' },
    { text: 'Be completely humble and gentle; be patient, bearing with one another in love.', ref: 'Ephesians 4:2' },
    { text: 'Be still before the Lord and wait patiently for him.', ref: 'Psalm 37:7' },
  ],
  gratitude: [
    { text: 'Give thanks in all circumstances; for this is God\'s will for you in Christ Jesus.', ref: '1 Thessalonians 5:18' },
    { text: 'Every good and perfect gift is from above, coming down from the Father of the heavenly lights.', ref: 'James 1:17' },
    { text: 'Enter his gates with thanksgiving and his courts with praise.', ref: 'Psalm 100:4' },
  ],
  forgiveness: [
    { text: 'Forgive as the Lord forgave you.', ref: 'Colossians 3:13' },
    { text: 'If you forgive other people when they sin against you, your heavenly Father will also forgive you.', ref: 'Matthew 6:14' },
    { text: 'Bear with each other and forgive one another if any of you has a grievance against someone. Forgive as the Lord forgave you.', ref: 'Colossians 3:13' },
  ],
  love: [
    { text: 'Love your neighbor as yourself.', ref: 'Mark 12:31' },
    { text: 'A new command I give you: Love one another. As I have loved you, so you must love one another.', ref: 'John 13:34' },
    { text: 'Dear friends, let us love one another, for love comes from God.', ref: '1 John 4:7' },
  ],
};

// Encouragement verses for when someone is off track
export const encouragementVerses: Verse[] = [
  { text: 'The Lord is close to the brokenhearted and saves those who are crushed in spirit.', ref: 'Psalm 34:18' },
  { text: 'For I know the plans I have for you, declares the Lord, plans to prosper you and not to harm you, plans to give you hope and a future.', ref: 'Jeremiah 29:11' },
  { text: 'Cast all your anxiety on him because he cares for you.', ref: '1 Peter 5:7' },
  { text: 'The Lord is my shepherd, I lack nothing.', ref: 'Psalm 23:1' },
  { text: 'Come to me, all you who are weary and burdened, and I will give you rest.', ref: 'Matthew 11:28' },
  { text: 'Do not be anxious about anything, but in every situation, by prayer and petition, with thanksgiving, present your requests to God.', ref: 'Philippians 4:6' },
  { text: 'The Lord is my strength and my shield; my heart trusts in him, and he helps me.', ref: 'Psalm 28:7' },
  { text: 'Even though I walk through the darkest valley, I will fear no evil, for you are with me.', ref: 'Psalm 23:4' },
];
