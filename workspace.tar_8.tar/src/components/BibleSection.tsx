import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BookOpen, Cross, Search, Star, Heart } from 'lucide-react';
import { bibleBooks, versesByMoral, encouragementVerses, jesusSayings, Verse } from '../data/bibleData';
import { morals } from '../data/moralData';

export default function BibleSection() {
  const [selectedBook, setSelectedBook] = useState<number | null>(null);
  const [selectedMoralVerses, setSelectedMoralVerses] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'books' | 'jesus' | 'morals'>('books');

  const filteredBooks = bibleBooks.filter(book =>
    book.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedBookData = selectedBook !== null ? bibleBooks.find(b => b.id === selectedBook) : null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
          <Cross className="text-amber-400" size={36} />
          Holy Bible
        </h1>
        <p className="text-gray-400 text-lg">All 66 books — Jesus' words in red — linked to your moral journey</p>
      </motion.div>

      {/* Tabs */}
      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {[
          { id: 'books' as const, label: 'All 66 Books', icon: <BookOpen size={18} /> },
          { id: 'jesus' as const, label: 'Words of Jesus', icon: <Cross size={18} /> },
          { id: 'morals' as const, label: 'Verses by Moral', icon: <Heart size={18} /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all ${
              activeTab === tab.id
                ? 'bg-amber-600/30 text-amber-300 border border-amber-500/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {/* All Books Tab */}
      {activeTab === 'books' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={20} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search books..."
              className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-amber-400 transition-all"
            />
          </div>

          {/* Old Testament */}
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span className="text-amber-400">📜</span> Old Testament (39 books)
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {filteredBooks.filter(b => b.testament === 'old').map((book, i) => (
                <motion.button
                  key={book.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.02 }}
                  onClick={() => setSelectedBook(book.id)}
                  className="bg-white/5 border border-white/10 rounded-xl p-3 hover:bg-white/10 hover:border-amber-500/30 transition-all text-left"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-bold text-sm">{book.name}</h3>
                    <span className="text-xs text-gray-500">{book.chapters}ch</span>
                  </div>
                  <p className="text-xs text-gray-400">{book.category}</p>
                </motion.button>
              ))}
            </div>
          </div>

          {/* New Testament */}
          <div>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span className="text-blue-400">✝️</span> New Testament (27 books)
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {filteredBooks.filter(b => b.testament === 'new').map((book, i) => (
                <motion.button
                  key={book.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.02 }}
                  onClick={() => setSelectedBook(book.id)}
                  className="bg-white/5 border border-white/10 rounded-xl p-3 hover:bg-white/10 hover:border-blue-500/30 transition-all text-left"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-bold text-sm">{book.name}</h3>
                    <span className="text-xs text-gray-500">{book.chapters}ch</span>
                  </div>
                  <p className="text-xs text-gray-400">{book.category}</p>
                </motion.button>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* Jesus' Words Tab */}
      {activeTab === 'jesus' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <div className="bg-gradient-to-r from-red-900/30 to-amber-900/30 border border-red-500/20 rounded-xl p-6 mb-6">
            <h2 className="text-xl font-bold mb-2 text-red-300">Words of Jesus in Red</h2>
            <p className="text-gray-300 text-sm">
              These are the actual words spoken by Jesus Christ, shown in red as traditionally printed in many Bibles.
            </p>
          </div>

          <div className="space-y-4">
            {jesusSayings.map((verse, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all"
              >
                <p className="text-lg text-red-400 italic mb-2 leading-relaxed">
                  "{verse.text}"
                </p>
                <p className="text-sm text-gray-400">— {verse.ref}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Verses by Moral Tab */}
      {activeTab === 'morals' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 border border-purple-500/20 rounded-xl p-6 mb-6">
            <h2 className="text-xl font-bold mb-2 text-purple-300">Verses Linked to Your Moral Journey</h2>
            <p className="text-gray-300 text-sm">
              These verses are connected to the morals you're learning. When you're off-track, these verses encourage you to get back on track.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 mb-6">
            {morals.map((moral, i) => (
              <motion.button
                key={moral.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
                onClick={() => setSelectedMoralVerses(moral.id)}
                className="bg-white/5 border border-white/10 rounded-xl p-3 hover:bg-white/10 hover:border-purple-500/30 transition-all text-left"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="text-2xl mb-1">{moral.emoji}</div>
                <h3 className="font-bold text-sm">{moral.title}</h3>
                <p className="text-xs text-gray-400">{versesByMoral[moral.id]?.length || 0} verses</p>
              </motion.button>
            ))}
          </div>

          {/* Encouragement Verses */}
          <div className="bg-blue-900/20 border border-blue-500/20 rounded-xl p-6">
            <h3 className="text-lg font-bold mb-4 text-blue-300 flex items-center gap-2">
              <Heart size={20} /> Encouragement Verses
            </h3>
            <p className="text-sm text-gray-400 mb-4">
              When you're feeling off-track, these verses remind you that God's love is new every morning.
            </p>
            <div className="space-y-3">
              {encouragementVerses.map((verse, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-white/5 rounded-lg p-4"
                >
                  <p className={`italic mb-1 ${verse.isJesus ? 'text-red-400' : 'text-gray-300'}`}>
                    "{verse.text}"
                  </p>
                  <p className="text-xs text-gray-500">— {verse.ref}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* Book Detail Modal */}
      <AnimatePresence>
        {selectedBookData && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelectedBook(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-gray-900 border border-white/20 rounded-2xl max-w-lg w-full max-h-[85vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="text-center mb-6">
                  <div className="text-5xl mb-3">
                    {selectedBookData.testament === 'old' ? '📜' : '✝️'}
                  </div>
                  <h2 className="text-3xl font-bold mb-1">{selectedBookData.name}</h2>
                  <p className="text-gray-400">{selectedBookData.category} • {selectedBookData.chapters} chapters</p>
                  <p className="text-sm text-gray-500 mt-1">
                    {selectedBookData.testament === 'old' ? 'Old Testament' : 'New Testament'}
                  </p>
                </div>

                {selectedBookData.keyVerse && (
                  <div className="bg-amber-500/20 border border-amber-500/30 rounded-xl p-4 mb-4">
                    <h3 className="font-bold text-amber-300 mb-2 flex items-center gap-2">
                      <Star size={18} /> Key Verse
                    </h3>
                    <p className="text-lg italic text-amber-100">"{selectedBookData.keyVerse}"</p>
                  </div>
                )}

                <div className="bg-white/5 rounded-xl p-4 mb-4">
                  <h3 className="font-bold text-blue-300 mb-2">About this book</h3>
                  <p className="text-sm text-gray-300">
                    {selectedBookData.name} is {selectedBookData.testament === 'old' ? 'part of the Old Testament' : 'part of the New Testament'}, 
                    {' '}categorized as {selectedBookData.category}. It contains {selectedBookData.chapters} chapters 
                    and is book #{selectedBookData.id} in the Bible.
                  </p>
                </div>

                <button
                  onClick={() => setSelectedBook(null)}
                  className="w-full py-3 bg-amber-600 hover:bg-amber-500 rounded-xl font-medium transition-all"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Moral Verses Modal */}
      <AnimatePresence>
        {selectedMoralVerses && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelectedMoralVerses(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-gray-900 border border-white/20 rounded-2xl max-w-lg w-full max-h-[85vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="text-center mb-6">
                  <div className="text-5xl mb-3">
                    {morals.find(m => m.id === selectedMoralVerses)?.emoji}
                  </div>
                  <h2 className="text-2xl font-bold mb-1">
                    {morals.find(m => m.id === selectedMoralVerses)?.title}
                  </h2>
                  <p className="text-gray-400">Verses to guide you</p>
                </div>

                <div className="space-y-3">
                  {versesByMoral[selectedMoralVerses]?.map((verse, i) => (
                    <div key={i} className="bg-white/5 rounded-xl p-4">
                      <p className={`italic mb-2 ${verse.isJesus ? 'text-red-400' : 'text-gray-300'}`}>
                        "{verse.text}"
                      </p>
                      <p className="text-sm text-gray-500">— {verse.ref}</p>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => setSelectedMoralVerses(null)}
                  className="w-full py-3 mt-6 bg-purple-600 hover:bg-purple-500 rounded-xl font-medium transition-all"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
