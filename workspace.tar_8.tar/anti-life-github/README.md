# Anti Life

A holistic web application for exploring psychology, life, relationships, morals, sports, entertainment, technology, and news.

## Features

- **Mind & Emotions**: Psychology, emotional intelligence, behavioral patterns
- **Life & Relationships**: Love, friendship, family, personal growth
- **Moral Tracker**: Daily reflection with praise/encouragement system
- **Sports**: 5 major European leagues with team records and history
- **Entertainment**: Movies, music, gaming, pop culture worldwide
- **Technology**: AI, gadgets, space, cybersecurity, innovation
- **News**: World, politics, science, business, health, environment

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository
```bash
git clone <your-repo-url>
cd anti-life
```

2. Install dependencies
```bash
npm install
```

3. Start the development server
```bash
npm run dev
```

4. Open your browser and visit `http://localhost:5173`

## Build for Production

```bash
npm run build
```

The built files will be in the `dist` directory.

## Tech Stack

- React 18
- TypeScript
- Vite
- Tailwind CSS
- Framer Motion
- Lucide React Icons

## Philosophy

1. **Curiosity over Assumptions** - Discover through reflection
2. **Connection over Isolation** - Build healthy relationships
3. **Individuality over One-Size-Fits-All** - Personalized experience
4. **Evidence over Hype** - Research-backed information
5. **Progress over Perfection** - Understand yourself better

## License

MIT
