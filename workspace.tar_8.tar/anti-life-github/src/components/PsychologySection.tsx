import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Lightbulb, Target, BookOpen, ChevronDown, ChevronUp, Sparkles, RotateCcw } from 'lucide-react';

interface PsychologySectionProps {
  userAge: number | null;
}

const emotionWheel = [
  { name: "Joy", color: "bg-yellow-500", emotions: ["Contentment", "Gratitude", "Pride", "Excitement", "Serenity", "Amusement"] },
  { name: "Sadness", color: "bg-blue-500", emotions: ["Loneliness", "Grief", "Disappointment", "Melancholy", "Helplessness", "Nostalgia"] },
  { name: "Anger", color: "bg-red-500", emotions: ["Frustration", "Resentment", "Irritation", "Rage", "Jealousy", "Bitterness"] },
  { name: "Fear", color: "bg-purple-500", emotions: ["Anxiety", "Dread", "Insecurity", "Panic", "Worry", "Vulnerability"] },
  { name: "Surprise", color: "bg-pink-500", emotions: ["Shock", "Awe", "Confusion", "Amazement", "Disbelief", "Wonder"] },
  { name: "Disgust", color: "bg-green-500", emotions: ["Contempt", "Revulsion", "Aversion", "Distaste", "Repulsion", "Disdain"] },
];

const psychologicalConcepts = [
  {
    title: "Emotional Intelligence (EQ)",
    description: "The ability to recognize, understand, and manage our own emotions and recognize, understand, and influence the emotions of others.",
    research: "Research by Daniel Goleman shows EQ can be more important than IQ for success and well-being.",
    evidence: "Strong evidence",
    practices: ["Journal your emotions daily", "Practice naming emotions precisely", "Pause before reacting", "Develop empathy through active listening"],
    icon: "🧠"
  },
  {
    title: "Cognitive Behavioral Patterns",
    description: "Our thoughts, feelings, and behaviors are interconnected. Changing one can change the others.",
    research: "CBT is one of the most researched and effective therapeutic approaches worldwide.",
    evidence: "Strong evidence",
    practices: ["Identify negative thought patterns", "Challenge cognitive distortions", "Keep a thought record", "Practice behavioral experiments"],
    icon: "🔄"
  },
  {
    title: "Attachment Theory",
    description: "Our early relationships shape how we connect with others. Understanding your attachment style can transform your relationships.",
    research: "Developed by John Bowlby and Mary Ainsworth. Styles: Secure, Anxious, Avoidant, Disorganized.",
    evidence: "Strong evidence",
    practices: ["Reflect on your early relationships", "Notice your relationship patterns", "Practice secure behaviors", "Communicate needs clearly"],
    icon: "🔗"
  },
  {
    title: "Flow State",
    description: "That state of complete absorption in an activity where time seems to disappear. The peak of human experience.",
    research: "Mihaly Csikszentmihalyi's research shows flow occurs when challenge matches skill level.",
    evidence: "Strong evidence",
    practices: ["Find activities that challenge you appropriately", "Eliminate distractions", "Set clear goals", "Focus on the process, not the outcome"],
    icon: "🌊"
  },
  {
    title: "The Shadow Self",
    description: "The parts of ourselves we hide or deny. Integrating the shadow leads to wholeness.",
    research: "Carl Jung's concept. Modern psychology confirms that suppressed aspects of self affect behavior.",
    evidence: "Moderate evidence (theoretical framework)",
    practices: ["Notice what triggers you in others", "Journal about uncomfortable feelings", "Accept all parts of yourself", "Explore your projections"],
    icon: "🌑"
  },
  {
    title: "Neuroplasticity",
    description: "Your brain can physically change and rewire itself throughout your entire life. You are never stuck.",
    research: "Research shows meditation, learning, and new experiences physically change brain structure.",
    evidence: "Strong evidence",
    practices: ["Learn new skills regularly", "Practice mindfulness meditation", "Challenge your routines", "Exercise regularly (boosts BDNF)"],
    icon: "⚡"
  },
  {
    title: "Self-Determination Theory",
    description: "Three universal needs drive human motivation: Autonomy, Competence, and Relatedness.",
    research: "Edward Deci and Richard Ryan's research shows these needs are essential for well-being across cultures.",
    evidence: "Strong evidence",
    practices: ["Cultivate autonomy in choices", "Develop competence in areas you care about", "Nurture meaningful connections", "Align actions with values"],
    icon: "🎯"
  },
  {
    title: "The Hedonic Treadmill",
    description: "We adapt to both positive and negative changes, returning to a baseline level of happiness.",
    research: "Studies show lottery winners and accident victims return to similar happiness levels after a year.",
    evidence: "Moderate evidence (individual variation exists)",
    practices: ["Practice gratitude regularly", "Seek variety and novelty", "Focus on experiences over possessions", "Cultivate meaning, not just pleasure"],
    icon: "🎡"
  },
];

const reflectionPrompts = [
  "What emotion have you been avoiding lately, and what might it be trying to tell you?",
  "When did you last feel completely absorbed in something? What was it?",
  "What pattern in your relationships keeps repeating? What might be the lesson?",
  "If your anxiety could speak, what would it say it's protecting you from?",
  "What would you do differently if you weren't afraid of being judged?",
  "What part of yourself do you hide from others? What would happen if you showed it?",
  "When do you feel most like yourself? What conditions create that feeling?",
  "What belief about yourself might actually be a story you tell, not a truth?",
  "What are you grateful for today that you took for granted yesterday?",
  "If you could have a conversation with your younger self, what would you say?",
];

export default function PsychologySection({ userAge }: PsychologySectionProps) {
  const [selectedEmotion, setSelectedEmotion] = useState<number | null>(null);
  const [expandedConcept, setExpandedConcept] = useState<number | null>(null);
  const [currentPrompt, setCurrentPrompt] = useState(0);
  const [journalEntry, setJournalEntry] = useState('');
  const [savedEntries, setSavedEntries] = useState<string[]>([]);

  const handleNewPrompt = () => {
    setCurrentPrompt((prev) => (prev + 1) % reflectionPrompts.length);
  };

  const handleSaveEntry = () => {
    if (journalEntry.trim()) {
      setSavedEntries([journalEntry, ...savedEntries]);
      setJournalEntry('');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
          <Brain className="text-blue-400" size={36} />
          Mind & Emotions
        </h1>
        <p className="text-gray-400 text-lg">Understanding your inner world — psychology, emotions, and behavior explained</p>
      </motion.div>

      {/* Emotion Wheel */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-12"
      >
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <Sparkles className="text-yellow-400" size={24} />
          Emotion Wheel — Identify What You Feel
        </h2>
        <p className="text-gray-400 mb-4">Click on an emotion to explore its nuances. Naming emotions precisely is the first step to understanding them.</p>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-4">
          {emotionWheel.map((emotion, i) => (
            <motion.button
              key={i}
              onClick={() => setSelectedEmotion(selectedEmotion === i ? null : i)}
              className={`p-4 rounded-xl border transition-all ${
                selectedEmotion === i 
                  ? 'border-white/50 scale-105 shadow-lg' 
                  : 'border-white/10 hover:border-white/30'
              } bg-white/5`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className={`w-8 h-8 rounded-full ${emotion.color} mx-auto mb-2`} />
              <span className="font-medium text-sm">{emotion.name}</span>
            </motion.button>
          ))}
        </div>

        <AnimatePresence>
          {selectedEmotion !== null && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-white/5 border border-white/10 rounded-xl p-4"
            >
              <h3 className="font-bold text-lg mb-2">{emotionWheel[selectedEmotion].name} — Sub-emotions</h3>
              <div className="flex flex-wrap gap-2">
                {emotionWheel[selectedEmotion].emotions.map((e, i) => (
                  <span key={i} className={`px-3 py-1 rounded-full text-sm ${emotionWheel[selectedEmotion].color} bg-opacity-20 border border-white/20`}>
                    {e}
                  </span>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.section>

      {/* Psychological Concepts */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mb-12"
      >
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <BookOpen className="text-purple-400" size={24} />
          Psychological Concepts — Evidence-Based Understanding
        </h2>
        <p className="text-gray-400 mb-4">Explore key concepts in psychology. We clearly label what's well-supported by research vs. what's theoretical.</p>
        
        <div className="space-y-3">
          {psychologicalConcepts.map((concept, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + i * 0.05 }}
              className="bg-white/5 border border-white/10 rounded-xl overflow-hidden"
            >
              <button
                onClick={() => setExpandedConcept(expandedConcept === i ? null : i)}
                className="w-full p-4 text-left flex items-center gap-3 hover:bg-white/5 transition-all"
              >
                <span className="text-2xl">{concept.icon}</span>
                <div className="flex-1">
                  <h3 className="font-bold">{concept.title}</h3>
                  <p className="text-sm text-gray-400">{concept.description}</p>
                </div>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  concept.evidence === 'Strong evidence' ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'
                }`}>
                  {concept.evidence}
                </span>
                {expandedConcept === i ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
              </button>
              
              <AnimatePresence>
                {expandedConcept === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="px-4 pb-4"
                  >
                    <div className="bg-white/5 rounded-lg p-4 space-y-3">
                      <div>
                        <h4 className="font-semibold text-purple-300 text-sm mb-1">Research</h4>
                        <p className="text-sm text-gray-300">{concept.research}</p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-green-300 text-sm mb-1">Try This</h4>
                        <ul className="space-y-1">
                          {concept.practices.map((p, j) => (
                            <li key={j} className="text-sm text-gray-300 flex items-start gap-2">
                              <span className="text-green-400 mt-1">•</span>
                              {p}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* Reflection & Journal */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mb-12"
      >
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <Lightbulb className="text-yellow-400" size={24} />
          Reflection Space — Curiosity Over Assumptions
        </h2>
        <p className="text-gray-400 mb-4">Instead of telling you what's right, we help you discover it through reflection. Try these prompts:</p>
        
        <div className="bg-gradient-to-r from-yellow-900/30 to-orange-900/30 border border-yellow-500/20 rounded-xl p-6 mb-4">
          <p className="text-lg text-yellow-100 italic mb-4">"{reflectionPrompts[currentPrompt]}"</p>
          <button
            onClick={handleNewPrompt}
            className="flex items-center gap-2 px-4 py-2 bg-yellow-500/20 hover:bg-yellow-500/30 rounded-lg text-yellow-300 text-sm transition-all"
          >
            <RotateCcw size={16} /> New Prompt
          </button>
        </div>

        {/* Journal */}
        <div className="bg-white/5 border border-white/10 rounded-xl p-4">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <Target className="text-purple-400" size={20} />
            Your Private Journal
          </h3>
          <textarea
            value={journalEntry}
            onChange={(e) => setJournalEntry(e.target.value)}
            placeholder="Write your thoughts here... This stays on your device."
            className="w-full h-32 px-4 py-3 bg-white/5 border border-purple-500/20 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-purple-400 resize-none"
          />
          <button
            onClick={handleSaveEntry}
            disabled={!journalEntry.trim()}
            className="mt-3 px-4 py-2 bg-purple-600 hover:bg-purple-500 rounded-lg text-sm font-medium transition-all disabled:opacity-50"
          >
            Save Entry
          </button>
          
          {savedEntries.length > 0 && (
            <div className="mt-4 space-y-2">
              <h4 className="text-sm font-medium text-gray-400">Previous entries:</h4>
              {savedEntries.slice(0, 3).map((entry, i) => (
                <div key={i} className="bg-white/5 rounded-lg p-3 text-sm text-gray-300">
                  {entry.substring(0, 150)}{entry.length > 150 ? '...' : ''}
                </div>
              ))}
            </div>
          )}
        </div>
      </motion.section>

      {/* Age-appropriate note */}
      {userAge && userAge < 18 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-blue-900/30 border border-blue-500/20 rounded-xl p-4 text-sm text-blue-200"
        >
          💡 <strong>Note:</strong> If you're going through something difficult, talking to a trusted adult or counselor can really help. You don't have to figure everything out alone.
        </motion.div>
      )}
    </div>
  );
}
