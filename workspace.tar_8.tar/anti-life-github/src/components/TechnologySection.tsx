import { useState } from 'react';
import { motion } from 'framer-motion';
import { Cpu, Zap, Rocket, Shield, TrendingUp, Brain } from 'lucide-react';

export default function TechnologySection() {
  const [activeCategory, setActiveCategory] = useState('ai');

  const categories = [
    { id: 'ai', label: 'AI & ML', icon: <Brain size={18} /> },
    { id: 'gadgets', label: 'Gadgets', icon: <Zap size={18} /> },
    { id: 'space', label: 'Space', icon: <Rocket size={18} /> },
    { id: 'cyber', label: 'Cybersecurity', icon: <Shield size={18} /> },
    { id: 'innovation', label: 'Innovation', icon: <TrendingUp size={18} /> },
  ];

  const aiNews = [
    { title: "GPT-5 and the Future of Reasoning", desc: "OpenAI's latest model shows advances in logical reasoning.", impact: "High" },
    { title: "AI in Healthcare", desc: "AI systems helping diagnose rare diseases worldwide.", impact: "High" },
    { title: "The Energy Cost of AI", desc: "Research focuses on making AI more efficient.", impact: "Medium" },
  ];

  const gadgets = [
    { title: "Apple Vision Pro 2", desc: "Second gen spatial computer with improved comfort.", category: "AR/VR", price: "$2,499" },
    { title: "Samsung Galaxy S26", desc: "AI-powered smartphone with satellite connectivity.", category: "Smartphone", price: "$1,299" },
  ];

  const spaceNews = [
    { title: "Artemis III: Return to the Moon", desc: "NASA prepares to land humans on Moon's south pole.", status: "In Progress" },
    { title: "SpaceX Starship", desc: "Largest rocket ever built achieves regular flights.", status: "Active" },
  ];

  const cyberNews = [
    { title: "Post-Quantum Cryptography", desc: "New quantum-resistant encryption standards deployed.", urgency: "Important" },
    { title: "AI-Powered Cyber Attacks", desc: "Sophisticated AI-generated phishing increases.", urgency: "Critical" },
  ];

  const innovations = [
    { title: "Solid-State Batteries", desc: "2x energy density, faster charging, safer.", field: "Energy" },
    { title: "Lab-Grown Meat", desc: "Production scales up, price parity approaches.", field: "Food Tech" },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
          <Cpu className="text-orange-400" size={36} />
          Technology - Worldwide
        </h1>
        <p className="text-gray-400 text-lg">Latest innovations shaping our world</p>
      </motion.div>

      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {categories.map(cat => (
          <button key={cat.id} onClick={() => setActiveCategory(cat.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all ${
              activeCategory === cat.id ? 'bg-orange-600/30 text-orange-300 border border-orange-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}>
            {cat.icon} {cat.label}
          </button>
        ))}
      </div>

      {activeCategory === 'ai' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
          {aiNews.map((item, i) => (
            <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all">
              <div className="flex items-center gap-2 mb-2">
                <span className={`px-2 py-0.5 rounded text-xs font-medium ${item.impact === 'High' ? 'bg-red-500/20 text-red-300' : 'bg-yellow-500/20 text-yellow-300'}`}>{item.impact} Impact</span>
              </div>
              <h3 className="font-bold mb-1">{item.title}</h3>
              <p className="text-sm text-gray-400">{item.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      )}

      {activeCategory === 'gadgets' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {gadgets.map((item, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all">
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-bold">{item.title}</h3>
                <span className="px-2 py-0.5 bg-orange-500/20 rounded text-xs text-orange-300">{item.category}</span>
              </div>
              <p className="text-sm text-gray-400 mb-2">{item.desc}</p>
              <p className="text-sm font-medium text-orange-300">{item.price}</p>
            </motion.div>
          ))}
        </motion.div>
      )}

      {activeCategory === 'space' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
          {spaceNews.map((item, i) => (
            <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all">
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2 py-0.5 bg-blue-500/20 rounded text-xs text-blue-300">{item.status}</span>
              </div>
              <h3 className="font-bold mb-1">{item.title}</h3>
              <p className="text-sm text-gray-400">{item.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      )}

      {activeCategory === 'cyber' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
          {cyberNews.map((item, i) => (
            <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all">
              <div className="flex items-center gap-2 mb-2">
                <span className={`px-2 py-0.5 rounded text-xs font-medium ${item.urgency === 'Critical' ? 'bg-red-500/20 text-red-300' : 'bg-yellow-500/20 text-yellow-300'}`}>{item.urgency}</span>
              </div>
              <h3 className="font-bold mb-1">{item.title}</h3>
              <p className="text-sm text-gray-400">{item.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      )}

      {activeCategory === 'innovation' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {innovations.map((item, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all">
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2 py-0.5 bg-green-500/20 rounded text-xs text-green-300">{item.field}</span>
              </div>
              <h3 className="font-bold mb-1">{item.title}</h3>
              <p className="text-sm text-gray-400">{item.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
}
