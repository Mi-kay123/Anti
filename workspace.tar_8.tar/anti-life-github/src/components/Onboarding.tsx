import { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, ArrowRight, Brain, Heart, Globe } from 'lucide-react';

interface OnboardingProps {
  onComplete: (name: string, age: number) => void;
}

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(0);
  const [name, setName] = useState('');
  const [age, setAge] = useState('');

  const handleSubmit = () => {
    if (name.trim() && age) {
      onComplete(name.trim(), parseInt(age));
    }
  };

  const features = [
    { icon: <Brain size={32} />, title: "Mind & Emotions", desc: "Understand your psychology, emotions, and behavior" },
    { icon: <Heart size={32} />, title: "Life & Relationships", desc: "Navigate love, connection, and personal growth" },
    { icon: <Globe size={32} />, title: "World at Your Fingertips", desc: "Sports, Entertainment, Tech & News from around the globe" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 flex items-center justify-center p-4">
      <div className="max-w-lg w-full">
        {step === 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="inline-block mb-6"
            >
              <Sparkles className="text-purple-400 mx-auto" size={64} />
            </motion.div>
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
              Anti Life
            </h1>
            <p className="text-xl text-gray-300 mb-2">
              Not anti-life. Pro-<span className="text-purple-300 font-semibold">understanding</span> life.
            </p>
            <p className="text-gray-400 mb-8 max-w-md mx-auto">
              A holistic space to explore your emotions, psychology, relationships, and the world — designed for those who think deeply and feel intensely.
            </p>

            <div className="space-y-4 mb-8">
              {features.map((f, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + i * 0.2 }}
                  className="flex items-center gap-4 bg-white/5 backdrop-blur-sm border border-purple-500/20 rounded-xl p-4 text-left"
                >
                  <div className="text-purple-400">{f.icon}</div>
                  <div>
                    <h3 className="font-semibold text-white">{f.title}</h3>
                    <p className="text-sm text-gray-400">{f.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.button
              onClick={() => setStep(1)}
              className="px-8 py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full font-semibold text-lg hover:shadow-lg hover:shadow-purple-500/25 transition-all"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Begin Your Journey
            </motion.button>
          </motion.div>
        )}

        {step === 1 && (
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white/5 backdrop-blur-xl border border-purple-500/20 rounded-2xl p-8"
          >
            <h2 className="text-2xl font-bold mb-2 text-center">Let's get to know you</h2>
            <p className="text-gray-400 text-center mb-6">This helps us personalize your experience</p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  What should we call you?
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name or nickname"
                  className="w-full px-4 py-3 bg-white/10 border border-purple-500/30 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-400/20 transition-all"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  How old are you?
                </label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  placeholder="Your age"
                  min="10"
                  max="120"
                  className="w-full px-4 py-3 bg-white/10 border border-purple-500/30 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-400/20 transition-all"
                />
              </div>

              <motion.button
                onClick={handleSubmit}
                disabled={!name.trim() || !age}
                className="w-full mt-6 px-8 py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl font-semibold text-lg hover:shadow-lg hover:shadow-purple-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                whileHover={{ scale: name.trim() && age ? 1.02 : 1 }}
                whileTap={{ scale: name.trim() && age ? 0.98 : 1 }}
              >
                Enter Anti Life <ArrowRight size={20} />
              </motion.button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
