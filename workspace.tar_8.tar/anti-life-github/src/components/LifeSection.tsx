import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, MessageCircle, Users, Shield, Sparkles, ArrowRight, RotateCcw } from 'lucide-react';

interface LifeSectionProps {
  userAge: number | null;
}

const loveLanguages = [
  { name: "Words of Affirmation", icon: "💬", desc: "Verbal expressions of love, appreciation, and encouragement", examples: ["Compliments", "Encouraging words", "Frequent 'I love you's", "Written notes"] },
  { name: "Quality Time", icon: "⏰", desc: "Undivided attention and shared experiences", examples: ["Deep conversations", "Shared activities", "Being present", "Eye contact"] },
  { name: "Receiving Gifts", icon: "🎁", desc: "Thoughtful tokens that show you're thinking of them", examples: ["Handmade items", "Surprise gifts", "Remembering favorites", "Thoughtful gestures"] },
  { name: "Acts of Service", icon: "🤲", desc: "Actions that ease their burden or show care", examples: ["Cooking meals", "Running errands", "Helping with tasks", "Taking initiative"] },
  { name: "Physical Touch", icon: "🤗", desc: "Physical connection that communicates warmth and safety", examples: ["Holding hands", "Hugs", "Physical closeness", "Comforting touch"] },
];

const relationshipTopics = [
  {
    title: "Building Emotional Intimacy",
    description: "Emotional intimacy is the foundation of deep connection. It's the ability to be vulnerable with another person and feel safe doing so.",
    research: "Research by Brené Brown shows vulnerability is the birthplace of connection. Studies confirm that emotional intimacy predicts relationship satisfaction more than any other factor.",
    tips: ["Share fears and dreams, not just daily events", "Listen without trying to fix", "Ask 'How did that make you feel?'", "Create rituals of connection"],
    icon: "💝"
  },
  {
    title: "Healthy Conflict Resolution",
    description: "Conflict isn't the enemy of relationships — avoiding conflict is. Learning to fight fair is essential.",
    research: "John Gottman's research identifies 'The Four Horsemen': Criticism, Contempt, Defensiveness, and Stonewalling as relationship killers. Repair attempts are the key difference.",
    tips: ["Use 'I feel' instead of 'You always'", "Take breaks when flooded (20 min minimum)", "Never bring up past grievances", "Focus on the issue, not the person"],
    icon: "⚖️"
  },
  {
    title: "The Science of Attraction",
    description: "Attraction is complex — involving biology, psychology, and social factors. Understanding it helps you make conscious choices.",
    research: "Research shows similarity in values matters more than 'opposites attract'. Proximity, reciprocity, and physical attractiveness all play roles. The 'mere exposure effect' is real.",
    tips: ["Notice what you're attracted to and why", "Don't confuse intensity with compatibility", "Shared values predict long-term success", "Attachment styles influence who we're drawn to"],
    icon: "✨"
  },
  {
    title: "Friendship & Community",
    description: "Humans are wired for connection. Quality friendships are as important as romantic relationships for well-being.",
    research: "The Harvard Study of Adult Development (85+ years running) found that quality relationships are the #1 predictor of happiness and longevity.",
    tips: ["Invest in 3-5 close friendships", "Be the friend you want to have", "Show up consistently, not just in crisis", "Allow friendships to evolve over time"],
    icon: "👥"
  },
  {
    title: "Self-Love & Boundaries",
    description: "You cannot pour from an empty cup. Self-love isn't selfish — it's the foundation for loving others well.",
    research: "Self-compassion research by Kristin Neff shows it reduces anxiety and depression while increasing resilience and relationship satisfaction.",
    tips: ["Set boundaries without guilt", "Practice self-compassion when you struggle", "Meet your own needs before expecting others to", "Know your values and live by them"],
    icon: "🛡️"
  },
  {
    title: "Grief & Loss",
    description: "Loss is the price of love. Understanding grief helps us navigate it with more grace.",
    research: "Kübler-Ross's stages aren't linear. Modern grief research shows there's no 'right way' to grieve. Dual Process Model suggests oscillating between loss and restoration.",
    tips: ["Allow all emotions without judgment", "Don't rush the process", "Seek connection, not isolation", "Honor the loss in your own way"],
    icon: "🕊️"
  },
];

const connectionExperiments = [
  "Send a message to someone you haven't talked to in a while — just to say you're thinking of them",
  "Ask someone 'What's been on your mind lately?' and really listen",
  "Write down 3 things you appreciate about someone and tell them",
  "Join a community group or class related to something you care about",
  "Have a conversation where you ask more questions than you give answers",
  "Reach out to someone who might be lonely — a neighbor, colleague, or acquaintance",
  "Share something vulnerable with a trusted friend this week",
  "Practice giving your full attention in one conversation today — no phone, no distractions",
];

export default function LifeSection({ userAge }: LifeSectionProps) {
  const [activeTab, setActiveTab] = useState<'explore' | 'languages' | 'experiments'>('explore');
  const [expandedTopic, setExpandedTopic] = useState<number | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [currentExperiment, setCurrentExperiment] = useState(0);

  const handleQuizAnswer = (answer: number) => {
    const newAnswers = [...quizAnswers, answer];
    setQuizAnswers(newAnswers);
    if (newAnswers.length >= 5) {
      setShowResults(true);
    }
  };

  const getLoveLanguageResult = () => {
    const counts = [0, 0, 0, 0, 0];
    quizAnswers.forEach(a => counts[a]++);
    const maxIndex = counts.indexOf(Math.max(...counts));
    return loveLanguages[maxIndex];
  };

  const resetQuiz = () => {
    setQuizAnswers([]);
    setShowResults(false);
  };

  const quizQuestions = [
    "You'd feel most loved if your partner/friend:",
    "After a hard day, what helps most?",
    "What makes you feel most connected?",
    "What would hurt most in a relationship?",
    "How do you naturally show care?",
  ];

  const quizOptions = [
    ["Tells you they're proud of you", "Spends the whole evening with you", "Surprises you with something thoughtful", "Does something helpful for you", "Gives you a long hug"],
    ["Hearing 'I believe in you'", "Having someone just sit with you", "Receiving a caring gift", "Someone handling your chores", "Physical comfort and closeness"],
    ["Deep, meaningful conversations", "Quality time together", "Thoughtful gestures", "Acts of kindness", "Physical affection"],
    ["Harsh words or criticism", "Being ignored or neglected", "Forgotten special dates", "Having to do everything alone", "Physical distance or rejection"],
    ["Tell them what I admire", "Plan special time together", "Find the perfect gift", "Help them without being asked", "Show affection physically"],
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
          <Heart className="text-pink-400" size={36} />
          Life & Relationships
        </h1>
        <p className="text-gray-400 text-lg">Navigating love, connection, and the human experience — with evidence, not platitudes</p>
      </motion.div>

      {/* Tab Navigation */}
      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {[
          { id: 'explore' as const, label: 'Explore Topics', icon: <MessageCircle size={18} /> },
          { id: 'languages' as const, label: 'Love Language Quiz', icon: <Sparkles size={18} /> },
          { id: 'experiments' as const, label: 'Connection Experiments', icon: <Users size={18} /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all ${
              activeTab === tab.id
                ? 'bg-pink-600/30 text-pink-300 border border-pink-500/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {/* Explore Topics */}
      {activeTab === 'explore' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
          {relationshipTopics.map((topic, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-white/5 border border-white/10 rounded-xl overflow-hidden"
            >
              <button
                onClick={() => setExpandedTopic(expandedTopic === i ? null : i)}
                className="w-full p-4 text-left flex items-center gap-3 hover:bg-white/5 transition-all"
              >
                <span className="text-2xl">{topic.icon}</span>
                <div className="flex-1">
                  <h3 className="font-bold">{topic.title}</h3>
                  <p className="text-sm text-gray-400">{topic.description}</p>
                </div>
                <ArrowRight size={20} className={`transition-transform ${expandedTopic === i ? 'rotate-90' : ''}`} />
              </button>
              
              <AnimatePresence>
                {expandedTopic === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="px-4 pb-4"
                  >
                    <div className="bg-white/5 rounded-lg p-4 space-y-3">
                      <div>
                        <h4 className="font-semibold text-pink-300 text-sm mb-1">What Research Shows</h4>
                        <p className="text-sm text-gray-300">{topic.research}</p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-green-300 text-sm mb-1">Practical Tips</h4>
                        <ul className="space-y-1">
                          {topic.tips.map((tip, j) => (
                            <li key={j} className="text-sm text-gray-300 flex items-start gap-2">
                              <span className="text-pink-400 mt-1">•</span>
                              {tip}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* Love Language Quiz */}
      {activeTab === 'languages' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          {!showResults ? (
            <div className="bg-white/5 border border-white/10 rounded-xl p-6">
              <h2 className="text-xl font-bold mb-2">Discover Your Love Language</h2>
              <p className="text-gray-400 mb-6">Answer 5 questions to discover how you most naturally give and receive love. This isn't definitive — it's a starting point for self-discovery.</p>
              
              {quizAnswers.length < 5 && (
                <div>
                  <div className="mb-2 text-sm text-gray-400">
                    Question {quizAnswers.length + 1} of 5
                  </div>
                  <h3 className="text-lg font-semibold mb-4">{quizQuestions[quizAnswers.length]}</h3>
                  <div className="space-y-2">
                    {quizOptions[quizAnswers.length].map((option, i) => (
                      <motion.button
                        key={i}
                        onClick={() => handleQuizAnswer(i)}
                        className="w-full p-3 text-left bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 hover:border-pink-500/30 transition-all"
                        whileHover={{ scale: 1.01 }}
                        whileTap={{ scale: 0.99 }}
                      >
                        {option}
                      </motion.button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-gradient-to-r from-pink-900/30 to-purple-900/30 border border-pink-500/20 rounded-xl p-6">
              <h2 className="text-2xl font-bold mb-4">Your Love Language: {getLoveLanguageResult().name} {getLoveLanguageResult().icon}</h2>
              <p className="text-gray-300 mb-4">{getLoveLanguageResult().desc}</p>
              <div className="mb-4">
                <h3 className="font-semibold text-pink-300 mb-2">This might look like:</h3>
                <div className="flex flex-wrap gap-2">
                  {getLoveLanguageResult().examples.map((ex, i) => (
                    <span key={i} className="px-3 py-1 bg-pink-500/20 rounded-full text-sm text-pink-200">{ex}</span>
                  ))}
                </div>
              </div>
              <p className="text-sm text-gray-400 mb-4">
                <strong>Note:</strong> Love languages aren't rigid categories. You likely use multiple languages, and they can change over time. This is a conversation starter, not a diagnosis.
              </p>
              <button
                onClick={resetQuiz}
                className="flex items-center gap-2 px-4 py-2 bg-pink-600/30 hover:bg-pink-600/50 rounded-lg text-pink-300 text-sm transition-all"
              >
                <RotateCcw size={16} /> Take Quiz Again
              </button>
            </div>
          )}
        </motion.div>
      )}

      {/* Connection Experiments */}
      {activeTab === 'experiments' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <div className="bg-white/5 border border-white/10 rounded-xl p-6 mb-4">
            <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
              <Shield className="text-green-400" size={24} />
              Connection Experiments
            </h2>
            <p className="text-gray-400 mb-4">
              Small, evidence-based actions to build connection. These aren't prescriptions — they're experiments. Try one and notice what happens.
            </p>
          </div>

          <div className="bg-gradient-to-r from-green-900/30 to-teal-900/30 border border-green-500/20 rounded-xl p-6">
            <div className="text-sm text-green-300 mb-2">Experiment {currentExperiment + 1} of {connectionExperiments.length}</div>
            <p className="text-xl text-white mb-6">{connectionExperiments[currentExperiment]}</p>
            <button
              onClick={() => setCurrentExperiment((currentExperiment + 1) % connectionExperiments.length)}
              className="flex items-center gap-2 px-4 py-2 bg-green-600/30 hover:bg-green-600/50 rounded-lg text-green-300 text-sm transition-all"
            >
              Next Experiment <ArrowRight size={16} />
            </button>
          </div>

          <div className="mt-6 bg-blue-900/30 border border-blue-500/20 rounded-xl p-4">
            <p className="text-sm text-blue-200">
              💡 <strong>Important:</strong> This app cannot replace real human connection. If you're feeling deeply isolated, consider reaching out to a professional or community group. You deserve real connection.
            </p>
          </div>
        </motion.div>
      )}
    </div>
  );
}
