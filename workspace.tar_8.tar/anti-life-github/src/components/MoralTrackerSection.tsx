import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Star, TrendingUp, Award, CheckCircle, XCircle, Sparkles } from 'lucide-react';
import { morals, encouragementMessages, praiseMessages, DailyReflection } from '../data/moralData';

interface MoralTrackerSectionProps {
  userAge: number | null;
}

export default function MoralTrackerSection({ userAge }: MoralTrackerSectionProps) {
  const [selectedMoral, setSelectedMoral] = useState<string | null>(null);
  const [dailyReflection, setDailyReflection] = useState<string>('');
  const [todayActions, setTodayActions] = useState<string[]>([]);
  const [isOnTrack, setIsOnTrack] = useState<boolean | null>(null);
  const [streak, setStreak] = useState<number>(0);
  const [totalDays, setTotalDays] = useState<number>(0);
  const [showResult, setShowResult] = useState<boolean>(false);
  const [encouragementVerse, setEncouragementVerse] = useState<string>('');

  useEffect(() => {
    // Load data from localStorage
    const savedStreak = localStorage.getItem('moralStreak');
    const savedTotal = localStorage.getItem('moralTotalDays');
    if (savedStreak) setStreak(parseInt(savedStreak));
    if (savedTotal) setTotalDays(parseInt(savedTotal));
  }, []);

  const handleReflectionSubmit = () => {
    if (!dailyReflection.trim()) return;

    // Simple analysis - check if reflection contains positive moral keywords
    const reflection = dailyReflection.toLowerCase();
    const moralKeywords = {
      honesty: ['truth', 'honest', 'told', 'admitted', 'real'],
      kindness: ['helped', 'kind', 'nice', 'shared', 'cared'],
      courage: ['brave', 'stood up', 'tried', 'faced', 'bold'],
      forgiveness: ['forgave', 'let go', 'moved on', 'peace'],
      gratitude: ['thankful', 'grateful', 'appreciate', 'blessed'],
      respect: ['listened', 'honored', 'respected', 'polite'],
      patience: ['waited', 'calm', 'patient', 'understood'],
      generosity: ['gave', 'shared', 'donated', 'generous'],
      humility: ['humble', 'learned', 'listened', 'modest'],
      responsibility: ['did', 'completed', 'finished', 'responsible'],
      compassion: ['felt for', 'cared about', 'understood', 'empathy'],
      integrity: ['right thing', 'honest', 'true', 'principled'],
    };

    const matchedMorals: string[] = [];
    Object.entries(moralKeywords).forEach(([moral, keywords]) => {
      if (keywords.some(keyword => reflection.includes(keyword))) {
        matchedMorals.push(moral);
      }
    });

    // If no specific morals matched, default to positive
    const aligned = matchedMorals.length > 0;
    setIsOnTrack(aligned);
    setShowResult(true);

    if (aligned) {
      setStreak(prev => prev + 1);
      localStorage.setItem('moralStreak', (streak + 1).toString());
    } else {
      setStreak(0);
      localStorage.setItem('moralStreak', '0');
      // Get a random encouragement message
      const randomEncouragement = encouragementMessages[Math.floor(Math.random() * encouragementMessages.length)];
      setEncouragementVerse(randomEncouragement);
    }

    setTotalDays(prev => prev + 1);
    localStorage.setItem('moralTotalDays', (totalDays + 1).toString());
    setTodayActions(matchedMorals);
  };

  const resetReflection = () => {
    setDailyReflection('');
    setIsOnTrack(null);
    setShowResult(false);
    setTodayActions([]);
  };

  const selectedMoralData = morals.find(m => m.id === selectedMoral);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
          <Heart className="text-pink-400" size={36} />
          Moral Tracker
        </h1>
        <p className="text-gray-400 text-lg">Learn, reflect, and grow every day</p>
      </motion.div>

      {/* Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
      >
        <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 border border-orange-500/30 rounded-xl p-4 text-center">
          <div className="text-3xl mb-1">🔥</div>
          <div className="text-2xl font-bold text-orange-300">{streak}</div>
          <div className="text-xs text-gray-400">Day Streak</div>
        </div>
        <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border border-blue-500/30 rounded-xl p-4 text-center">
          <div className="text-3xl mb-1">📅</div>
          <div className="text-2xl font-bold text-blue-300">{totalDays}</div>
          <div className="text-xs text-gray-400">Total Days</div>
        </div>
        <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30 rounded-xl p-4 text-center">
          <div className="text-3xl mb-1">⭐</div>
          <div className="text-2xl font-bold text-purple-300">{morals.length}</div>
          <div className="text-xs text-gray-400">Morals to Learn</div>
        </div>
        <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-xl p-4 text-center">
          <div className="text-3xl mb-1">🌟</div>
          <div className="text-2xl font-bold text-green-300">{todayActions.length}</div>
          <div className="text-xs text-gray-400">Today's Morals</div>
        </div>
      </motion.div>

      {/* Daily Reflection */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border border-purple-500/20 rounded-2xl p-6 mb-8"
      >
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <Sparkles className="text-yellow-400" size={24} />
          What did you do today?
        </h2>
        <p className="text-gray-300 mb-4">
          Tell me about your day! What choices did you make? How did you treat others?
        </p>
        
        {!showResult ? (
          <>
            <textarea
              value={dailyReflection}
              onChange={(e) => setDailyReflection(e.target.value)}
              placeholder="Today I..."
              className="w-full h-32 px-4 py-3 bg-white/10 border border-purple-500/30 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-purple-400 resize-none mb-4"
            />
            <button
              onClick={handleReflectionSubmit}
              disabled={!dailyReflection.trim()}
              className="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl font-semibold text-lg hover:shadow-lg hover:shadow-purple-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Reflect on My Day ✨
            </button>
          </>
        ) : (
          <AnimatePresence>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="space-y-4"
            >
              {isOnTrack ? (
                <>
                  <div className="bg-green-500/20 border border-green-500/30 rounded-xl p-6 text-center">
                    <CheckCircle className="text-green-400 mx-auto mb-3" size={48} />
                    <h3 className="text-2xl font-bold text-green-300 mb-2">
                      {praiseMessages[Math.floor(Math.random() * praiseMessages.length)]}
                    </h3>
                    <p className="text-gray-300">
                      You showed {todayActions.length > 0 ? todayActions.slice(0, 3).map(m => morals.find(mor => mor.id === m)?.title).join(', ') : 'great character'} today!
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <div className="bg-blue-500/20 border border-blue-500/30 rounded-xl p-6 text-center">
                    <Heart className="text-blue-400 mx-auto mb-3" size={48} />
                    <h3 className="text-2xl font-bold text-blue-300 mb-2">
                      {encouragementMessages[Math.floor(Math.random() * encouragementMessages.length)]}
                    </h3>
                    <div className="bg-white/10 rounded-lg p-4 mt-4">
                      <p className="text-sm text-gray-300 mb-2">Here's a verse to encourage you:</p>
                      <p className="text-lg italic text-yellow-200">"{encouragementVerse}"</p>
                    </div>
                  </div>
                </>
              )}
              
              <button
                onClick={resetReflection}
                className="w-full py-3 bg-white/10 hover:bg-white/20 rounded-xl font-medium transition-all"
              >
                Reflect Again
              </button>
            </motion.div>
          </AnimatePresence>
        )}
      </motion.div>

      {/* Morals Grid */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <Sparkles className="text-purple-400" size={24} />
          Learn About Morals
        </h2>
        <p className="text-gray-400 mb-6">Click on any moral to learn more about it</p>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {morals.map((moral, i) => (
            <motion.button
              key={moral.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + i * 0.05 }}
              onClick={() => setSelectedMoral(moral.id)}
              className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 hover:border-purple-500/30 transition-all text-left"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="text-4xl mb-2">{moral.emoji}</div>
              <h3 className="font-bold text-lg mb-1">{moral.title}</h3>
              <p className="text-xs text-gray-400 line-clamp-2">{moral.kidExplanation}</p>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Moral Detail Modal */}
      <AnimatePresence>
        {selectedMoralData && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelectedMoral(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-gray-900 border border-white/20 rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="text-center mb-6">
                  <div className="text-6xl mb-3">{selectedMoralData.emoji}</div>
                  <h2 className="text-3xl font-bold mb-2">{selectedMoralData.title}</h2>
                </div>

                {/* Kid-friendly explanation */}
                <div className="bg-purple-500/20 border border-purple-500/30 rounded-xl p-4 mb-4">
                  <h3 className="font-bold text-purple-300 mb-2">What it means:</h3>
                  <p className="text-gray-300">{selectedMoralData.kidExplanation}</p>
                </div>

                {/* Deeper meaning */}
                <div className="bg-white/5 rounded-xl p-4 mb-4">
                  <h3 className="font-bold text-blue-300 mb-2">Deeper understanding:</h3>
                  <p className="text-gray-300 text-sm">{selectedMoralData.deeperMeaning}</p>
                </div>

                {/* Examples */}
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div className="bg-green-500/20 border border-green-500/30 rounded-xl p-4">
                    <h3 className="font-bold text-green-300 mb-2 flex items-center gap-2">
                      <CheckCircle size={18} /> Good Example
                    </h3>
                    <p className="text-gray-300 text-sm">{selectedMoralData.example}</p>
                  </div>
                  <div className="bg-red-500/20 border border-red-500/30 rounded-xl p-4">
                    <h3 className="font-bold text-red-300 mb-2 flex items-center gap-2">
                      <XCircle size={18} /> Not This
                    </h3>
                    <p className="text-gray-300 text-sm">{selectedMoralData.antiExample}</p>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedMoral(null)}
                  className="w-full py-3 bg-purple-600 hover:bg-purple-500 rounded-xl font-medium transition-all"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
