import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Tv, Film, Music, Gamepad2, Star, TrendingUp, X, Calendar, Users, Clapperboard } from 'lucide-react';
import { entertainmentData, EntertainmentItem } from '../data/entertainmentData';

export default function EntertainmentSection() {
  const [activeCategory, setActiveCategory] = useState('movies');
  const [selectedItem, setSelectedItem] = useState<EntertainmentItem | null>(null);

  const categories = [
    { id: 'movies', label: 'Movies', icon: <Film size={18} /> },
    { id: 'music', label: 'Music', icon: <Music size={18} /> },
    { id: 'gaming', label: 'Gaming', icon: <Gamepad2 size={18} /> },
    { id: 'trending', label: 'Trending', icon: <TrendingUp size={18} /> },
  ];

  const filteredItems = entertainmentData.filter(item => item.category === activeCategory);
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold flex items-center gap-3">
          <Tv className="text-purple-400" size={36} />
          Entertainment - Worldwide
        </h1>
        <p className="text-gray-400 text-lg mt-2">Movies, music, gaming, and pop culture from around the globe</p>
        <p className="text-sm text-purple-300 mt-1">💡 Click on any item to see full details, cast, and more</p>
      </motion.div>

      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {categories.map(cat => (
          <button key={cat.id} onClick={() => setActiveCategory(cat.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all ${
              activeCategory === cat.id ? 'bg-purple-600/30 text-purple-300 border border-purple-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}>
            {cat.icon} {cat.label}
          </button>
        ))}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredItems.map((item, i) => (
          <motion.button
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            onClick={() => setSelectedItem(item)}
            className="text-left bg-white/5 border border-white/10 rounded-xl overflow-hidden hover:bg-white/10 hover:border-purple-500/30 transition-all group"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {/* Visual Header */}
            <div className={`h-32 bg-gradient-to-br ${item.gradient} flex items-center justify-center relative overflow-hidden`}>
              <span className="text-6xl opacity-80 group-hover:scale-110 transition-transform">{item.image}</span>
              {item.rating && (
                <div className="absolute top-3 right-3 flex items-center gap-1 bg-black/50 backdrop-blur-sm px-2 py-1 rounded-lg">
                  <Star size={12} className="text-yellow-400 fill-yellow-400" />
                  <span className="text-xs font-bold text-white">{item.rating}</span>
                </div>
              )}
              {item.status && (
                <div className="absolute top-3 left-3 bg-black/50 backdrop-blur-sm px-2 py-1 rounded-lg">
                  <span className="text-xs font-medium text-white">{item.status}</span>
                </div>
              )}
            </div>
            
            {/* Content */}
            <div className="p-4">
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-bold text-lg group-hover:text-purple-300 transition-colors">{item.title}</h3>
              </div>
              <div className="flex gap-2 mb-2 flex-wrap">
                {item.genre && <span className="px-2 py-0.5 bg-purple-500/20 rounded text-xs text-purple-300">{item.genre}</span>}
                {item.year && <span className="px-2 py-0.5 bg-white/10 rounded text-xs text-gray-400">{item.year}</span>}
                {item.platform && <span className="px-2 py-0.5 bg-blue-500/20 rounded text-xs text-blue-300">{item.platform}</span>}
              </div>
              <p className="text-sm text-gray-400 line-clamp-2">{item.description}</p>
              <div className="mt-3 flex items-center gap-1 text-purple-400 text-xs font-medium">
                <span>View details</span>
                <span className="group-hover:translate-x-1 transition-transform">→</span>
              </div>
            </div>
          </motion.button>
        ))}
      </motion.div>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedItem && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelectedItem(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-gray-900 border border-white/20 rounded-2xl max-w-lg w-full max-h-[85vh] overflow-y-auto"
            >
              {/* Hero Image */}
              <div className={`h-48 bg-gradient-to-br ${selectedItem.gradient} flex items-center justify-center relative`}>
                <span className="text-8xl">{selectedItem.image}</span>
                <button
                  onClick={() => setSelectedItem(null)}
                  className="absolute top-4 right-4 p-2 bg-black/50 backdrop-blur-sm rounded-full hover:bg-black/70 transition-all"
                >
                  <X size={20} className="text-white" />
                </button>
                {selectedItem.rating && (
                  <div className="absolute bottom-4 right-4 flex items-center gap-1 bg-black/50 backdrop-blur-sm px-3 py-1.5 rounded-lg">
                    <Star size={14} className="text-yellow-400 fill-yellow-400" />
                    <span className="text-sm font-bold text-white">{selectedItem.rating}</span>
                  </div>
                )}
              </div>

              <div className="p-6">
                <h2 className="text-2xl font-bold mb-2">{selectedItem.title}</h2>
                
                <div className="flex gap-2 mb-4 flex-wrap">
                  {selectedItem.genre && <span className="px-3 py-1 bg-purple-500/20 rounded-full text-sm text-purple-300">{selectedItem.genre}</span>}
                  {selectedItem.year && <span className="px-3 py-1 bg-white/10 rounded-full text-sm text-gray-400">{selectedItem.year}</span>}
                  {selectedItem.platform && <span className="px-3 py-1 bg-blue-500/20 rounded-full text-sm text-blue-300">{selectedItem.platform}</span>}
                  {selectedItem.status && <span className="px-3 py-1 bg-green-500/20 rounded-full text-sm text-green-300">{selectedItem.status}</span>}
                </div>

                <p className="text-gray-300 mb-6 leading-relaxed">{selectedItem.description}</p>

                {/* Details */}
                <div className="bg-white/5 rounded-xl p-4 mb-4">
                  <h3 className="font-semibold text-purple-300 mb-3 flex items-center gap-2">
                    <TrendingUp size={18} /> Key Details
                  </h3>
                  <ul className="space-y-2">
                    {selectedItem.details.map((detail, idx) => (
                      <li key={idx} className="text-sm text-gray-300 flex items-start gap-2">
                        <span className="text-purple-400 mt-1">•</span>
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Cast */}
                {selectedItem.cast && (
                  <div className="bg-white/5 rounded-xl p-4 mb-4">
                    <h3 className="font-semibold text-purple-300 mb-3 flex items-center gap-2">
                      <Users size={18} /> Cast
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedItem.cast.map((person, idx) => (
                        <span key={idx} className="px-3 py-1 bg-white/10 rounded-full text-sm text-gray-300">{person}</span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Director */}
                {selectedItem.director && (
                  <div className="bg-white/5 rounded-xl p-4 mb-4">
                    <h3 className="font-semibold text-purple-300 mb-2 flex items-center gap-2">
                      <Clapperboard size={18} /> Director
                    </h3>
                    <p className="text-gray-300">{selectedItem.director}</p>
                  </div>
                )}

                <button
                  onClick={() => setSelectedItem(null)}
                  className="w-full py-3 bg-purple-600 hover:bg-purple-500 rounded-xl font-medium transition-all"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
