export interface Team {
  name: string;
  city: string;
  founded: number;
  stadium: string;
  titles: number;
  history: string;
  color: string;
  recentUpdates?: string[];
  records?: string[];
}

export interface League {
  name: string;
  country: string;
  flag: string;
  teams: Team[];
}

export const leagues: League[] = [
  {
    name: "Premier League",
    country: "England",
    flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    teams: [
      { name: "Manchester City", city: "Manchester", founded: 1880, stadium: "Etihad Stadium", titles: 9, history: "Rise to dominance in the 2010s with record-breaking seasons. Known for possession-based football under Pep Guardiola.", color: "#6CABDD", recentUpdates: ["Pep Guardiola announces contract extension through 2025", "Erling Haaland breaks Premier League single-season scoring record", "City completes historic treble in 2022-23 season"], records: ["Most consecutive Premier League wins (18)", "Most points in a Premier League season (100)", "First English men's team to win the treble"] },
      { name: "Arsenal", city: "London", founded: 1886, stadium: "Emirates Stadium", titles: 13, history: "The Invincibles season of 2003-04 remains legendary. A club built on beautiful, attacking football.", color: "#EF0107", recentUpdates: ["Mikel Arteta builds young, dynamic squad", "Bukayo Saka becomes club's most valuable player", "Strong title challenge in 2022-23 season"], records: ["Only unbeaten Premier League season (2003-04)", "49 games unbeaten (2003-04)", "Most FA Cup wins (14)"] },
      { name: "Liverpool", city: "Liverpool", founded: 1892, stadium: "Anfield", titles: 19, history: "England's most successful club in Europe with 6 Champions League titles. Famous for 'You'll Never Walk Alone'.", color: "#C8102E", recentUpdates: ["Jurgen Klopp announces departure after 9 years", "Virgil van Dijk signs new long-term contract", "Record-breaking 99-point season in 2019-20"], records: ["Most European Cups/Champions League titles by English club (6)", "Longest unbeaten home run in European top 5 leagues (68 games)", "Most points in a 38-game Premier League season (99)"] },
      { name: "Manchester United", city: "Manchester", founded: 1878, stadium: "Old Trafford", titles: 20, history: "The most successful English club historically. Sir Alex Ferguson era defined an generation of football.", color: "#DA291C", recentUpdates: ["Erik ten Hag implements new playing philosophy", "Rasmus Hojlund leads attacking rebuild", "FA Cup victory in 2023-24 season"], records: ["Most English league titles (20)", "Treble winners 1998-99", "Most FA Cup semi-final appearances (32)"] },
      { name: "Chelsea", city: "London", founded: 1905, stadium: "Stamford Bridge", titles: 6, history: "Transformed into a European powerhouse in the 2000s. Won the Champions League twice.", color: "#034694", recentUpdates: ["Todd Boehly completes major squad overhaul", "Cole Palmer emerges as star performer", "New stadium development plans announced"], records: ["Most Europa League titles (2)", "First London club to win Champions League", "Most English top-flight titles by a London club (6)"] },
      { name: "Tottenham Hotspur", city: "London", founded: 1882, stadium: "Tottenham Hotspur Stadium", titles: 2, history: "First British club to win a European trophy. Known for attacking philosophy and developing young talent.", color: "#132257", recentUpdates: ["Ange Postecoglou implements attacking style", "Son Heung-min reaches 100+ Premier League goals", "New stadium becomes one of world's best venues"], records: ["First British club to win a European trophy (1963)", "First club to win both UEFA Cup and Cup Winners' Cup", "Longest unbeaten start to a Premier League season (11 games, 2008)"] },
      { name: "Newcastle United", city: "Newcastle", founded: 1892, stadium: "St James' Park", titles: 4, history: "A passionate fanbase in the North East. The Magpies have a rich history and recent ambitious ownership.", color: "#241F20", recentUpdates: ["PIF ownership invests heavily in squad", "Champions League return after 20-year absence", "Eddie Howe builds competitive team"], records: ["Most Inter-Cities Fairs Cup titles (shared record)", "Longest unbeaten home run in English football (78 games, 1920s)", "Most English league titles by a Northern club (4)"] },
      { name: "Aston Villa", city: "Birmingham", founded: 1874, stadium: "Villa Park", titles: 7, history: "One of England's founding clubs. European Cup winners in 1982. A club with deep roots and recent resurgence.", color: "#670E36", recentUpdates: ["Unai Emery leads Champions League qualification", "Ollie Watkins becomes England regular", "Conference League winners 2024"], records: ["European Cup winners 1982", "One of only 5 English clubs to win the European Cup", "Founding member of the Football League (1888)"] },
      { name: "Brighton & Hove Albion", city: "Brighton", founded: 1901, stadium: "Amex Stadium", titles: 0, history: "A model club for data-driven recruitment and attractive football. Rising force in English football.", color: "#0057B8" },
      { name: "West Ham United", city: "London", founded: 1895, stadium: "London Stadium", titles: 0, history: "The Academy of Football. Won the 1966 World Cup with three England players. Europa Conference League winners 2023.", color: "#7A263A" },
      { name: "Crystal Palace", city: "London", founded: 1905, stadium: "Selhurst Park", titles: 0, history: "The Eagles have established themselves as a solid Premier League club with passionate supporters.", color: "#1B458F" },
      { name: "Fulham", city: "London", founded: 1879, stadium: "Craven Cottage", titles: 0, history: "London's oldest professional club. A charming club with a beautiful riverside stadium.", color: "#000000" },
      { name: "Wolverhampton Wanderers", city: "Wolverhampton", founded: 1877, stadium: "Molineux", titles: 3, history: "Founding members of the Football League. Three-time English champions in the 1950s.", color: "#FDB913" },
      { name: "Bournemouth", city: "Bournemouth", founded: 1899, stadium: "Vitality Stadium", titles: 0, history: "A remarkable rise from non-league to Premier League. Known for exciting, attacking football.", color: "#DA291C" },
      { name: "Brentford", city: "London", founded: 1889, stadium: "Gtech Community Stadium", titles: 0, history: "Pioneers in data analytics in football. Promoted to the Premier League and established themselves.", color: "#E30613" },
      { name: "Everton", city: "Liverpool", founded: 1878, stadium: "Goodison Park", titles: 9, history: "One of England's oldest clubs. Moving to a new stadium at Bramley-Moore Dock.", color: "#003399" },
      { name: "Nottingham Forest", city: "Nottingham", founded: 1865, stadium: "City Ground", titles: 1, history: "Back-to-back European Cups in 1979 and 1980 under Brian Clough. The world's oldest football league club.", color: "#DD0000" },
      { name: "Leicester City", city: "Leicester", founded: 1884, stadium: "King Power Stadium", titles: 1, history: "The greatest underdog story in sports - Premier League champions in 2016 at 5000-1 odds.", color: "#003090" },
      { name: "Ipswich Town", city: "Ipswich", founded: 1878, stadium: "Portman Road", titles: 1, history: "A club with a proud history including a league title and UEFA Cup win. Recently returned to the top flight.", color: "#0044AA" },
      { name: "Southampton", city: "Southampton", founded: 1885, stadium: "St Mary's Stadium", titles: 0, history: "Known for developing world-class talent. The Saints have a passionate community connection.", color: "#D71920" },
    ]
  },
  {
    name: "La Liga",
    country: "Spain",
    flag: "🇪🇸",
    teams: [
      { name: "Real Madrid", city: "Madrid", founded: 1902, stadium: "Santiago Bernabéu", titles: 36, history: "The most successful club in European football with 15 Champions League titles. The Galácticos era defined modern football.", color: "#FEBE10", recentUpdates: ["Jude Bellingham becomes instant star", "Vinicius Jr. leads attacking revolution", "15th Champions League title in 2024"], records: ["Most Champions League titles (15)", "Most consecutive Champions League titles (5, 1956-60)", "Most European Cup finals appearances (17)"] },
      { name: "Barcelona", city: "Barcelona", founded: 1899, stadium: "Camp Nou", titles: 27, history: "More than a club. The tiki-taka philosophy under Guardiola changed football forever. La Masia academy produces world-class talent.", color: "#A50044", recentUpdates: ["Lamine Yamal becomes youngest goalscorer", "Hansi Flick implements new tactical approach", "Camp Nou renovation nearing completion"], records: ["Most Copa del Rey titles (31)", "Treble winners 2008-09", "Most Spanish league titles in 21st century (10)"] },
      { name: "Atlético Madrid", city: "Madrid", founded: 1903, stadium: "Cívitas Metropolitano", titles: 11, history: "The gritty underdogs who broke the Real-Barca duopoly. Diego Simeone built a defensive masterclass.", color: "#272E61" },
      { name: "Athletic Bilbao", city: "Bilbao", founded: 1898, stadium: "San Mamés", titles: 8, history: "Unique cantera policy - only Basque players. A club deeply tied to Basque identity and culture.", color: "#EE2523" },
      { name: "Real Sociedad", city: "San Sebastián", founded: 1909, stadium: "Reale Arena", titles: 2, history: "A beautiful club from the Basque coast known for attractive football and developing local talent.", color: "#0067B1" },
      { name: "Real Betis", city: "Seville", founded: 1907, stadium: "Benito Villamarín", titles: 1, history: "The passionate green-and-white of Seville. Known for flair, creativity and the most passionate fans.", color: "#00954C" },
      { name: "Sevilla FC", city: "Seville", founded: 1890, stadium: "Ramón Sánchez-Pizjuán", titles: 1, history: "The kings of the Europa League with 7 titles. A club built on European nights and passion.", color: "#D40E1B" },
      { name: "Villarreal", city: "Villarreal", founded: 1923, stadium: "Estadio de la Cerámica", titles: 0, history: "The Yellow Submarine - a small town club that became a European force. Consistent Champions League participants.", color: "#FFE667" },
      { name: "Valencia", city: "Valencia", founded: 1919, stadium: "Mestalla", titles: 6, history: "Two-time Champions League finalist. A historic club that dominated Spanish football in the early 2000s.", color: "#EE3524" },
      { name: "Girona", city: "Girona", founded: 1930, stadium: "Montilivi", titles: 0, history: "A fairy-tale rise to challenge for La Liga. City Football Group's jewel with attractive football.", color: "#CD2534" },
      { name: "Celta Vigo", city: "Vigo", founded: 1923, stadium: "Abanca-Balaídos", titles: 0, history: "The Sky Blues of Galicia. Known for exciting attacking football and producing talented players.", color: "#8AC3EE" },
      { name: "Osasuna", city: "Pamplona", founded: 1920, stadium: "El Sadar", titles: 0, history: "A gritty, hardworking club from Navarre. Known for fighting spirit and passionate supporters.", color: "#D91A2A" },
      { name: "Mallorca", city: "Palma de Mallorca", founded: 1916, stadium: "Estadi Mallorca Son Moix", titles: 0, history: "The Balearic Islands' representative in top-flight football. A club with resilience and island pride.", color: "#E20613" },
      { name: "Getafe", city: "Getafe", founded: 1983, stadium: "Coliseum", titles: 0, history: "Known for their physical, defensive style. A club that punches above its weight consistently.", color: "#005999" },
      { name: "Rayo Vallecano", city: "Madrid", founded: 1924, stadium: "Vallecas", titles: 0, history: "The people's club of Madrid. Working-class roots, passionate fans, and a commitment to social values.", color: "#E53027" },
      { name: "Las Palmas", city: "Las Palmas", founded: 1949, stadium: "Estadio Gran Canaria", titles: 0, history: "The Canary Islands' team. Known for possession-based football despite limited resources.", color: "#FFE41C" },
      { name: "Alavés", city: "Vitoria-Gasteiz", founded: 1921, stadium: "Mendizorrotza", titles: 0, history: "A Basque club that reached the UEFA Cup final in 2001. Resilient and community-focused.", color: "#005CA8" },
      { name: "Cádiz", city: "Cádiz", founded: 1910, stadium: "Nuevo Mirandilla", titles: 0, history: "The oldest club in Andalusia. A small club with big heart and passionate supporters.", color: "#FFFF00" },
      { name: "Almería", city: "Almería", founded: 1989, stadium: "Power Horse Stadium", titles: 0, history: "A young club from southern Spain that has shown remarkable ambition in reaching La Liga.", color: "#E30613" },
      { name: "Granada", city: "Granada", founded: 1931, stadium: "Nuevo Los Cármenes", titles: 0, history: "A historic Andalusian club with passionate fans. Known for resilience and fighting spirit.", color: "#D40E2B" },
    ]
  },
  {
    name: "Bundesliga",
    country: "Germany",
    flag: "🇩🇪",
    teams: [
      { name: "Bayern Munich", city: "Munich", founded: 1900, stadium: "Allianz Arena", titles: 33, history: "Germany's record champions. A global powerhouse known for dominance and the famous treble of 2020.", color: "#DC052D", recentUpdates: ["Harry Kane breaks scoring records in debut season", "Vincent Kompany appointed as new head coach", "Historic treble in 2019-20 season"], records: ["Most consecutive Bundesliga titles (11, 2013-2023)", "Most German league titles (33)", "Most DFB-Pokal titles (20)"] },
      { name: "Borussia Dortmund", city: "Dortmund", founded: 1909, stadium: "Signal Iduna Park", titles: 8, history: "The Yellow Wall - Europe's most famous stand. A club built on passion, youth development and attacking football.", color: "#FDE100", recentUpdates: ["Jude Bellingham transfer to Real Madrid", "Mats Hummels returns for final season", "Champions League final appearance 2024"], records: ["The Yellow Wall - largest standing terrace in Europe (25,000)", "Champions League winners 1997", "Most German Cup finals appearances (6)"] },
      { name: "RB Leipzig", city: "Leipzig", founded: 2009, stadium: "Red Bull Arena", titles: 0, history: "The controversial newcomer that rose to the top in just over a decade. Modern football business model.", color: "#DD0741" },
      { name: "Bayer Leverkusen", city: "Leverkusen", founded: 1904, stadium: "BayArena", titles: 1, history: "The unbeaten season of 2023-24 under Xabi Alonso. Never Again Second place - they finally won it all.", color: "#E32221" },
      { name: "Borussia Mönchengladbach", city: "Mönchengladbach", founded: 1900, stadium: "Borussia-Park", titles: 5, history: "A dominant force in the 1970s. The Fohlen (Foals) are a club with rich European heritage.", color: "#1DB954" },
      { name: "Eintracht Frankfurt", city: "Frankfurt", founded: 1899, stadium: "Deutsche Bank Park", titles: 1, history: "Europa League champions 2022. Known for passionate fans and exciting European nights.", color: "#E1000F" },
      { name: "VfB Stuttgart", city: "Stuttgart", founded: 1893, stadium: "MHPArena", titles: 5, history: "A traditional German club with a passionate fanbase. Known for attractive football and youth development.", color: "#E32219" },
      { name: "Freiburg", city: "Freiburg", founded: 1904, stadium: "Europa-Park Stadion", titles: 0, history: "The model club of German football. Sustainable, well-run, and consistently punching above their weight.", color: "#242424" },
      { name: "Wolfsburg", city: "Wolfsburg", founded: 1945, stadium: "Volkswagen Arena", titles: 1, history: "A unique club born from a car factory. Champions in 2009 under Felix Magath.", color: "#65B32E" },
      { name: "Mainz 05", city: "Mainz", founded: 1905, stadium: "Mewa Arena", titles: 0, history: "A community-focused club known for developing talent and playing attractive football.", color: "#C30032" },
      { name: "Union Berlin", city: "Berlin", founded: 1906, stadium: "Stadion An der Alten Försterei", titles: 0, history: "The most romantic story in German football. From lower leagues to Champions League. Iron workers' club.", color: "#EB1923" },
      { name: "Hoffenheim", city: "Sinsheim", founded: 1899, stadium: "PreZero Arena", titles: 0, history: "The village club that defied all odds. Rose from lower leagues to Champions League.", color: "#1961B5" },
      { name: "Werder Bremen", city: "Bremen", founded: 1899, stadium: "Weserstadion", titles: 4, history: "A historic northern German club. Champions in the Otto Rehhagel era. Green and white passion.", color: "#1D9037" },
      { name: "FC Augsburg", city: "Augsburg", founded: 1907, stadium: "WWK Arena", titles: 0, history: "A resilient Bavarian club that has established itself in the Bundesliga despite limited resources.", color: "#BA3733" },
      { name: "FC Köln", city: "Cologne", founded: 1948, stadium: "RheinEnergieStadion", titles: 3, history: "The Billy Goats. A club with passionate fans and a rich history in German football.", color: "#ED1C24" },
      { name: "Heidenheim", city: "Heidenheim", founded: 1846, stadium: "Voith-Arena", titles: 0, history: "A fairy tale club from Germany's smallest Bundesliga city. Promotion to the top flight was historic.", color: "#E32219" },
      { name: "Darmstadt 98", city: "Darmstadt", founded: 1898, stadium: "Merck-Stadion am Böllenfalltor", titles: 0, history: "The Lilien - a club that embodies the spirit of German football's smaller clubs. Passionate and determined.", color: "#005BAA" },
      { name: "Holstein Kiel", city: "Kiel", founded: 1900, stadium: "Holstein-Stadion", titles: 0, history: "The Storks from northern Germany. A traditional club that finally reached the Bundesliga.", color: "#003B7A" },
    ]
  },
  {
    name: "Serie A",
    country: "Italy",
    flag: "🇮🇹",
    teams: [
      { name: "Juventus", city: "Turin", founded: 1897, stadium: "Allianz Stadium", titles: 36, history: "Italy's most successful club. The Old Lady has dominated Italian football for decades with a winning mentality.", color: "#000000", recentUpdates: ["Massimiliano Allegri returns as manager", "Dusan Vlahovic leads attack", "Rebuilding after Calciopoli scandal era"], records: ["Most Italian league titles (36)", "Most Coppa Italia titles (15)", "Only Italian club to win all UEFA competitions"] },
      { name: "AC Milan", city: "Milan", founded: 1899, stadium: "San Siro", titles: 19, history: "7-time European champions. The Rossoneri have a rich European heritage and a history of legendary players.", color: "#FB090B", recentUpdates: ["Stefano Pioli builds competitive squad", "Rafael Leao becomes star performer", "Serie A title in 2021-22"], records: ["Joint-most European Cup/Champions League titles (7)", "Most Italian Super Cup titles (7)", "Unbeaten Serie A season 1991-92 (58 games)"] },
      { name: "Inter Milan", city: "Milan", founded: 1908, stadium: "San Siro", titles: 20, history: "The treble winners of 2010. The Nerazzurri share the San Siro and a fierce rivalry with AC Milan.", color: "#0068A8", recentUpdates: ["Simone Inzaghi leads tactical revolution", "Lautaro Martinez becomes club legend", "Champions League final 2023"], records: ["Only Italian club to achieve the treble (2010)", "Most consecutive Serie A titles in modern era (5, 2006-2010)", "Most Italian league titles (20)"] },
      { name: "Napoli", city: "Naples", founded: 1926, stadium: "Diego Armando Maradona Stadium", titles: 3, history: "The passion of Naples. Maradona's legacy lives on. Scudetto winners in 2023 with spectacular football.", color: "#12A0D7", recentUpdates: ["Victor Osimhen becomes global star", "First Serie A title in 33 years (2023)", "Stadium renamed for Maradona"], records: ["First Southern Italian club to win Serie A (1987)", "Most goals in a single Serie A season (77, 2022-23)", "Maradona's legacy - greatest player to wear the shirt"] },
      { name: "AS Roma", city: "Rome", founded: 1927, stadium: "Stadio Olimpico", titles: 3, history: "The Wolves of Rome. Totti's legacy, passionate fans, and the eternal city's footballing heart.", color: "#8E1F2F" },
      { name: "Lazio", city: "Rome", founded: 1900, stadium: "Stadio Olimpico", titles: 2, history: "Rome's other club. The Biancocelesti have a proud history and fierce Derby della Capitale rivalry.", color: "#87D8F7" },
      { name: "Atalanta", city: "Bergamo", founded: 1907, stadium: "Gewiss Stadium", titles: 0, history: "The Goddess. A model club for attacking football and developing talent. Europa League winners 2024.", color: "#1E71B8" },
      { name: "Fiorentina", city: "Florence", founded: 1926, stadium: "Artemio Franchi", titles: 2, history: "The Viola. A club with Renaissance beauty in their football. Passionate fans in the city of art.", color: "#6B2D8B" },
      { name: "Bologna", city: "Bologna", founded: 1909, stadium: "Renato Dall'Ara", titles: 7, history: "A historic club with recent renaissance under Thiago Motta. Champions of Italy in the 1960s.", color: "#A31C34" },
      { name: "Torino", city: "Turin", founded: 1906, stadium: "Olimpico Grande Torino", titles: 7, history: "The Grande Torino tragedy of 1949. A club with deep emotion and the most passionate derby in Italy.", color: "#8B0000" },
      { name: "Monza", city: "Monza", founded: 1912, stadium: "U-Power Stadium", titles: 0, history: "Berlusconi's project that achieved the dream of Serie A promotion. A new force in Italian football.", color: "#CE2029" },
      { name: "Udinese", city: "Udine", founded: 1896, stadium: "Bluenergy Stadium", titles: 0, history: "A model club for scouting South American talent. Consistent Serie A presence with attractive football.", color: "#000000" },
      { name: "Sassuolo", city: "Sassuolo", founded: 1920, stadium: "Mapei Stadium", titles: 0, history: "The small-town club that reached Europe. Known for attacking football and developing young talent.", color: "#00A850" },
      { name: "Cagliari", city: "Cagliari", founded: 1920, stadium: "Unipol Domus", titles: 1, history: "Sardinia's pride. Won Serie A in 1970 with Gigi Riva. A club with island passion.", color: "#AC1A2C" },
      { name: "Lecce", city: "Lecce", founded: 1908, stadium: "Via del Mare", titles: 0, history: "The Giallorossi of the South. A club representing Salento's passion for football.", color: "#FFD700" },
      { name: "Genoa", city: "Genoa", founded: 1893, stadium: "Luigi Ferraris", titles: 9, history: "Italy's oldest club. A historic club with deep roots in Italian football history.", color: "#9B1B30" },
      { name: "Hellas Verona", city: "Verona", founded: 1903, stadium: "Marcantonio Bentegodi", titles: 1, history: "The miracle of 1985 - winning Serie A against all odds. A club with passionate fans.", color: "#FDB913" },
      { name: "Empoli", city: "Empoli", founded: 1920, stadium: "Castellani", titles: 0, history: "A model club for youth development. Consistently punching above their weight in Serie A.", color: "#005CA8" },
      { name: "Parma", city: "Parma", founded: 1913, stadium: "Ennio Tardini", titles: 0, history: "The golden era of the late 90s with Buffon, Cannavaro, Crespo. A phoenix club reborn from bankruptcy.", color: "#FFD700" },
      { name: "Como", city: "Como", founded: 1907, stadium: "Stadio Giuseppe Sinigaglia", titles: 0, history: "A beautiful lakeside club with a romantic story of return to Serie A. Hollywood ownership meets Italian tradition.", color: "#005CA8" },
    ]
  },
  {
    name: "Ligue 1",
    country: "France",
    flag: "🇫🇷",
    teams: [
      { name: "Paris Saint-Germain", city: "Paris", founded: 1970, stadium: "Parc des Princes", titles: 11, history: "Transformed into a global superclub. The Galacticos of Paris with a mission to win the Champions League.", color: "#004170", recentUpdates: ["Luis Enrique builds young, dynamic team", "Post-Mbappe era begins", "First Champions League title pursuit continues"], records: ["Most Ligue 1 titles in 21st century (11)", "Most expensive player signing (Neymar, €222m)", "Most French Cup titles (14)"] },
      { name: "Marseille", city: "Marseille", founded: 1899, stadium: "Stade Vélodrome", titles: 9, history: "The only French Champions League winner (1993). The most passionate fans in France. Le Classique.", color: "#2FAEE0", recentUpdates: ["Roberto De Zerbi appointed as manager", "Vélodrome atmosphere remains unmatched", "Rebuilding with young talent"], records: ["Only French club to win Champions League (1993)", "Most passionate fanbase in France", "Most European Cup final appearances by French club (3)"] },
      { name: "Monaco", city: "Monaco", founded: 1924, stadium: "Stade Louis II", titles: 8, history: "The glamorous club of the Riviera. A factory for world-class talent. Champions League finalists in 2004.", color: "#E2001A" },
      { name: "Lille", city: "Lille", founded: 1944, stadium: "Stade Pierre-Mauroy", titles: 4, history: "The surprise champions of 2021. A model club for scouting and developing talent on a budget.", color: "#E2001A" },
      { name: "Lyon", city: "Lyon", founded: 1950, stadium: "Groupama Stadium", titles: 7, history: "Seven consecutive titles 2002-2008. A historic powerhouse rebuilding with young talent.", color: "#1B3D73" },
      { name: "Nice", city: "Nice", founded: 1904, stadium: "Allianz Riviera", titles: 4, history: "A beautiful club on the French Riviera. Known for developing young talent and attractive football.", color: "#E2001A" },
      { name: "Lens", city: "Lens", founded: 1906, stadium: "Stade Bollaert-Delelis", titles: 1, history: "The passionate mining town club. The most atmospheric stadium in France. A club of the people.", color: "#F7D117" },
      { name: "Rennes", city: "Rennes", founded: 1901, stadium: "Roazhon Park", titles: 0, history: "Brittany's pride. Known for excellent youth academy and attractive football. Consistent European competitors.", color: "#E2001A" },
      { name: "Strasbourg", city: "Strasbourg", founded: 1906, stadium: "Stade de la Meinau", titles: 1, history: "A club at the crossroads of French and German culture. Blue and white passion in Alsace.", color: "#0066B3" },
      { name: "Toulouse", city: "Toulouse", founded: 1937, stadium: "Stadium de Toulouse", titles: 0, history: "The violet club from the pink city. Recent Coupe de France winners showing ambition.", color: "#6B2D8B" },
      { name: "Reims", city: "Reims", founded: 1931, stadium: "Stade Auguste-Delaune", titles: 6, history: "The dominant force of 1950s French football. Multiple European Cup finalists in the early years.", color: "#E2001A" },
      { name: "Montpellier", city: "Montpellier", founded: 1974, stadium: "Stade de la Mosson", titles: 1, history: "The surprise champions of 2012. A club from the south with passion and determination.", color: "#FF6600" },
      { name: "Nantes", city: "Nantes", founded: 1943, stadium: "Stade de la Beaujoire", titles: 8, history: "The famous 'Jeu à la Nantaise' - beautiful flowing football. A historic club with deep roots.", color: "#FFD700" },
      { name: "Brest", city: "Brest", founded: 1950, stadium: "Stade Francis-Le Blé", titles: 0, history: "The fairy tale of Brittany. A small club that achieved Champions League qualification. Pure romance.", color: "#E2001A" },
      { name: "Le Havre", city: "Le Havre", founded: 1872, stadium: "Stade Océane", titles: 0, history: "France's oldest club. A port city team with a rich history finally back in Ligue 1.", color: "#5CA0E3" },
      { name: "Auxerre", city: "Auxerre", founded: 1905, stadium: "Stade de l'Abbé-Deschamps", titles: 1, history: "The model French club under Guy Roux. Won the double in 1996. A legend of French football.", color: "#003B7A" },
      { name: "Angers", city: "Angers", founded: 1919, stadium: "Stade Raymond-Kopa", titles: 0, history: "A determined club from the Loire Valley. Known for resilience and community spirit.", color: "#E2001A" },
      { name: "Saint-Étienne", city: "Saint-Étienne", founded: 1919, stadium: "Stade Geoffroy-Guichard", titles: 10, history: "The most successful French club historically. The Green Giants with a legendary atmosphere.", color: "#00854A" },
    ]
  }
];

export const latestNews = [
  { id: 1, league: "Premier League", title: "Title race intensifies as top teams battle for supremacy", date: "2026-01-15" },
  { id: 2, league: "La Liga", title: "El Clásico preparations begin with both teams in strong form", date: "2026-01-14" },
  { id: 3, league: "Bundesliga", title: "Bayern face tough test as Leverkusen continue impressive run", date: "2026-01-13" },
  { id: 4, league: "Serie A", title: "Napoli and Inter locked in thrilling Scudetto race", date: "2026-01-12" },
  { id: 5, league: "Ligue 1", title: "PSG dominate but Marseille close the gap at the top", date: "2026-01-11" },
];
