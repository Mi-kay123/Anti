export interface EntertainmentItem {
  id: string;
  title: string;
  category: 'movies' | 'music' | 'gaming' | 'trending';
  image: string;
  gradient: string;
  rating?: number;
  year?: number;
  genre?: string;
  description: string;
  details: string[];
  cast?: string[];
  director?: string;
  platform?: string;
  status?: string;
}

export const entertainmentData: EntertainmentItem[] = [
  {
    id: 'dune-3',
    title: 'Dune: Part Three',
    category: 'movies',
    image: '🏜️',
    gradient: 'from-orange-600 to-red-900',
    rating: 9.1,
    year: 2026,
    genre: 'Sci-Fi',
    description: 'Denis Villeneuve concludes his epic adaptation of Frank Herbert\'s masterpiece. The final battle for Arrakis.',
    details: [
      'Director Denis Villeneuve completes the trilogy',
      'Based on Dune Messiah and Children of Dune',
      'Timothée Chalamet returns as Paul Atreides',
      'Filmed in IMAX for the ultimate experience',
      'Expected runtime: 3 hours',
      'Release date: Late 2026'
    ],
    cast: ['Timothée Chalamet', 'Zendaya', 'Josh Brolin', 'Florence Pugh', 'Javier Bardem'],
    director: 'Denis Villeneuve'
  },
  {
    id: 'batman-2',
    title: 'The Batman Part II',
    category: 'movies',
    image: '🦇',
    gradient: 'from-gray-800 to-red-900',
    rating: 8.7,
    year: 2026,
    genre: 'Action/Crime',
    description: 'Robert Pattinson returns as the Dark Knight in this noir-tinged sequel exploring Gotham\'s underworld.',
    details: [
      'Matt Reeves returns to direct',
      'Darker, more detective-focused storyline',
      'New villains to be revealed',
      'Filming began in early 2024',
      'Expected release: October 2026'
    ],
    cast: ['Robert Pattinson', 'Zoë Kravitz', 'Paul Dano', 'Jeffrey Wright'],
    director: 'Matt Reeves'
  },
  {
    id: 'kendrick',
    title: 'Kendrick Lamar',
    category: 'music',
    image: '🎤',
    gradient: 'from-purple-600 to-pink-600',
    genre: 'Hip-Hop',
    description: 'Pulitzer Prize winner continues to push boundaries with innovative sound and powerful lyrics.',
    details: [
      'Pulitzer Prize winner for DAMN. (2018)',
      'GNX album breaks streaming records',
      'Known for complex lyricism and social commentary',
      'Super Bowl halftime show 2025',
      'Multiple Grammy winner',
      'Influential in modern hip-hop'
    ]
  },
  {
    id: 'taylor',
    title: 'Taylor Swift',
    category: 'music',
    image: '🎵',
    gradient: 'from-pink-500 to-purple-600',
    genre: 'Pop',
    description: 'The Eras Tour becomes the highest-grossing tour in history. New music continues to break records.',
    details: [
      'Eras Tour: Highest-grossing tour ever ($2B+)',
      '14 Grammy Awards including 4 Album of the Year',
      'Re-recording her entire catalog',
      'The Tortured Poets Department breaks records',
      'Cultural icon and business mogul',
      'Time Person of the Year 2023'
    ]
  },
  {
    id: 'gta6',
    title: 'GTA VI',
    category: 'gaming',
    image: '🎮',
    gradient: 'from-green-600 to-blue-900',
    platform: 'PS5, Xbox Series X',
    status: 'Coming 2025/26',
    description: 'The most anticipated game in history. Return to Vice City with next-gen graphics and gameplay.',
    details: [
      'First GTA since 2013',
      'Set in modern-day Vice City (Miami)',
      'First female protagonist in series',
      'Largest open world Rockstar has created',
      'Online multiplayer from launch',
      'Expected to break sales records'
    ]
  },
  {
    id: 'zelda',
    title: 'Zelda: Tears of the Kingdom',
    category: 'gaming',
    image: '⚔️',
    gradient: 'from-green-500 to-emerald-700',
    platform: 'Nintendo Switch',
    status: 'Available',
    description: 'Nintendo\'s masterpiece of open-world creativity. Build, explore, and discover in Hyrule.',
    details: [
      'Sequel to Breath of the Wild (2017)',
      'Innovative building mechanics',
      'Massive open world to explore',
      '10/10 reviews worldwide',
      '20+ million copies sold',
      'Game of the Year 2023'
    ]
  },
  {
    id: 'ai-music',
    title: 'AI Music Debate',
    category: 'trending',
    image: '🤖',
    gradient: 'from-blue-600 to-purple-700',
    description: 'The music industry grapples with AI-created songs. Drake vs. AI controversy sparks discussion about authenticity.',
    details: [
      'AI-generated songs going viral',
      'Drake AI track sparks controversy',
      'Record labels developing AI policies',
      'Artists debating authenticity',
      'New copyright challenges',
      'Future of music creation uncertain'
    ]
  },
  {
    id: 'streaming',
    title: 'Streaming Wars Consolidation',
    category: 'trending',
    image: '📺',
    gradient: 'from-red-600 to-orange-700',
    description: 'Major platforms merge services. Disney+, Hulu, and Max bundle deals reshape content consumption.',
    details: [
      'Disney+ and Hulu bundle launched',
      'Max and Netflix compete for subscribers',
      'Ad-supported tiers growing',
      'Content costs rising dramatically',
      'Password sharing crackdowns',
      'Original content investment at all-time high'
    ]
  }
];
