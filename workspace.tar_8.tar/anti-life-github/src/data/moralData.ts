export interface Moral {
  id: string;
  title: string;
  emoji: string;
  kidExplanation: string;
  deeperMeaning: string;
  example: string;
  antiExample: string;
  bibleVerse: string;
  bibleRef: string;
  category: string;
}

export const morals: Moral[] = [
  {
    id: 'kindness',
    title: 'Kindness',
    emoji: '💝',
    kidExplanation: 'Kindness is like a superpower! When you\'re kind, you make someone smile. Even small things like sharing your toy or saying "please" and "thank you" are acts of kindness.',
    deeperMeaning: 'Being kind means treating others with warmth, care, and compassion. It\'s about thinking of others and making their day better. Kindness creates a ripple effect — when you\'re kind to someone, they\'re more likely to be kind to others.',
    example: 'Sharing your lunch with a friend who forgot theirs, or helping someone who fell down on the playground.',
    antiExample: 'Making fun of someone because they\'re different, or refusing to share when someone needs help.',
    bibleVerse: 'Be kind and compassionate to one another.',
    bibleRef: 'Ephesians 4:32',
    category: 'kindness'
  },
  {
    id: 'honesty',
    title: 'Honesty',
    emoji: '🌟',
    kidExplanation: 'Honesty means always telling the truth, even when you\'re scared. When you tell the truth, people trust you more. It\'s better to be honest and get in a little trouble than to lie and lose trust!',
    deeperMeaning: 'Honesty means telling the truth, even when it\'s hard. It builds trust and shows you are a person of integrity. When you\'re honest, people know they can count on you.',
    example: 'Telling mom you broke the vase even though you\'re scared, or admitting you didn\'t do your homework.',
    antiExample: 'Lying about what happened, cheating on a test, or blaming someone else for your mistake.',
    bibleVerse: 'The Lord detests lying lips, but he delights in people who are trustworthy.',
    bibleRef: 'Proverbs 12:22',
    category: 'honesty'
  },
  {
    id: 'respect',
    title: 'Respect',
    emoji: '🤝',
    kidExplanation: 'Respect means treating everyone nicely, even if they\'re different from you. It means listening when others talk, being polite to elders, and taking care of things that aren\'t yours.',
    deeperMeaning: 'Respect means treating everyone with dignity, listening to others, and valuing differences. It\'s honoring people and things. Respect shows that you value others as important people.',
    example: 'Listening when your teacher is talking, or being polite to the waiter at a restaurant.',
    antiExample: 'Interrupting others constantly, being rude to workers, or damaging public property.',
    bibleVerse: 'Show proper respect to everyone.',
    bibleRef: '1 Peter 2:17',
    category: 'respect'
  },
  {
    id: 'courage',
    title: 'Courage',
    emoji: '🦁',
    kidExplanation: 'Courage doesn\'t mean you\'re not scared. It means you do the right thing even when your tummy feels butterflies! Standing up for a friend, trying something new, or admitting a mistake all take courage.',
    deeperMeaning: 'Courage means doing what\'s right even when you\'re scared. It\'s not about not being afraid—it\'s about being brave despite fear. Courage helps you stand up for what\'s right.',
    example: 'Standing up to a bully who is picking on someone, or trying a new sport even though you\'re nervous.',
    antiExample: 'Picking on someone smaller than you, or going along with wrong things just because others are doing them.',
    bibleVerse: 'Be strong and courageous. Do not be afraid; do not be discouraged, for the Lord your God will be with you.',
    bibleRef: 'Joshua 1:9',
    category: 'courage'
  },
  {
    id: 'patience',
    title: 'Patience',
    emoji: '🌱',
    kidExplanation: 'Patience is like growing a seed into a flower—it takes time! When you\'re patient, you don\'t throw a fit when you have to wait. You take deep breaths and stay calm.',
    deeperMeaning: 'Patience means being able to wait calmly and not get angry when things don\'t go your way. It\'s a fruit of the spirit that helps us grow in character.',
    example: 'Waiting your turn in line without complaining, or staying calm when the internet is slow.',
    antiExample: 'Throwing a tantrum when you have to wait, or giving up when something is hard.',
    bibleVerse: 'Love is patient, love is kind.',
    bibleRef: '1 Corinthians 13:4',
    category: 'patience'
  },
  {
    id: 'gratitude',
    title: 'Gratitude',
    emoji: '🙏',
    kidExplanation: 'Gratitude means saying "thank you" to God and to people. It\'s being happy for what you have instead of always wanting more. Try thinking of 3 things you\'re thankful for every day!',
    deeperMeaning: 'Gratitude means being thankful for what you have. It shifts your focus from what you lack to the blessings in your life. Grateful people are happier people.',
    example: 'Saying thank you to your parents for making dinner, or being grateful for your toys instead of always wanting new ones.',
    antiExample: 'Complaining about everything you have, or never saying thank you when someone does something nice.',
    bibleVerse: 'Give thanks in all circumstances; for this is God\'s will for you.',
    bibleRef: '1 Thessalonians 5:18',
    category: 'gratitude'
  },
  {
    id: 'forgiveness',
    title: 'Forgiveness',
    emoji: '🕊️',
    kidExplanation: 'Forgiveness is like letting go of a heavy balloon. When someone says sorry and you forgive them, you feel lighter! It doesn\'t mean what they did was okay, but it means you don\'t want to stay angry.',
    deeperMeaning: 'Forgiveness means letting go of anger when someone hurts you. It doesn\'t mean what they did was okay—it means you choose peace. Forgiveness frees you from carrying anger.',
    example: 'Saying "I forgive you" when your friend apologizes for breaking your toy, or not staying mad at your sibling.',
    antiExample: 'Staying angry forever, getting revenge, or reminding someone of their past mistakes.',
    bibleVerse: 'Forgive as the Lord forgave you.',
    bibleRef: 'Colossians 3:13',
    category: 'forgiveness'
  },
  {
    id: 'love',
    title: 'Love',
    emoji: '❤️',
    kidExplanation: 'Love is the biggest, most important thing! Jesus said the most important command is to love God and love others. Love means caring about people, helping them, and wanting them to be happy.',
    deeperMeaning: 'Love is the greatest virtue. It means caring deeply for others, putting their needs first, and acting with compassion. Love is the foundation of all other morals.',
    example: 'Helping your family without being asked, or caring for a sick friend by bringing them soup.',
    antiExample: 'Being selfish and only thinking about yourself, or hurting others on purpose.',
    bibleVerse: 'Love your neighbor as yourself.',
    bibleRef: 'Mark 12:31',
    category: 'love'
  },
];

export const praiseMessages = [
  '🌟 Amazing! You made someone\'s day brighter!',
  '✨ Wonderful! You showed great character today!',
  '🎉 Fantastic! Your kindness is like a light to others!',
  '💫 Beautiful! You\'re growing into an amazing person!',
  '🏆 Great job! You made the right choice!',
  '🌈 Wonderful! Your actions show a beautiful heart!',
  '⭐ Excellent! You\'re a role model for others!',
  '🎊 Amazing! God is pleased with your choices!',
];

export const encouragementMessages = [
  '💪 Tomorrow is a new day! You can always choose to do better.',
  '🌱 Every mistake is a chance to grow. Try again tomorrow!',
  '🤗 It\'s okay! What matters is that you want to do better.',
  '🌟 Remember, even heroes have tough days. You\'ve got this!',
  '💝 God\'s love for you never changes. Try again tomorrow!',
  '🦋 Growth takes time. Be patient with yourself!',
  '🌻 Tomorrow is a fresh start. You can make different choices!',
  '🎯 Focus on progress, not perfection. You\'re doing great!',
];

export interface DailyReflection {
  date: string;
  moralLearned: string;
  action: string;
  inAlignment: boolean;
  praise?: string;
  encouragement?: string;
  verse?: string;
}
